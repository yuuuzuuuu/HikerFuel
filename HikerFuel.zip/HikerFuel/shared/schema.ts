import { pgTable, text, serial, integer, boolean, json, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Removing all references to the old meal planning app

// Base user schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Category types for expenses
export const expenseCategories = [
  "makanan",
  "transportasi",
  "belanja",
  "hiburan",
  "kesehatan",
  "pendidikan",
  "tagihan",
  "lainnya",
] as const;

// Payment methods
export const paymentMethods = [
  "tunai",
  "kartu-kredit",
  "kartu-debit",
  "e-wallet",
  "transfer-bank",
  "lainnya",
] as const;

// Budget periods
export const budgetPeriods = [
  "harian",
  "mingguan",
  "bulanan",
  "tahunan",
] as const;

// Expense schema
export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  amount: integer("amount").notNull(), // Amount in smallest currency unit (e.g. cents)
  description: text("description").notNull(),
  category: text("category").notNull(),
  date: timestamp("date").notNull().defaultNow(),
  paymentMethod: text("payment_method").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertExpenseSchema = createInsertSchema(expenses).omit({
  id: true,
  createdAt: true,
});

// Budget schema
export const budgets = pgTable("budgets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  name: text("name").notNull(),
  amount: integer("amount").notNull(), // Budget limit amount in smallest currency unit
  period: text("period").notNull(), // daily, weekly, monthly, yearly
  category: text("category"), // Optional: specific category this budget applies to
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"), // Optional: for one-time budgets
  isRecurring: boolean("is_recurring").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertBudgetSchema = createInsertSchema(budgets).omit({
  id: true,
  createdAt: true,
});

// Zod validation for expenses
export const expenseSchema = z.object({
  amount: z.number().int().positive("Amount must be positive"),
  description: z.string().min(2, "Description must be at least 2 characters long"),
  category: z.enum(expenseCategories),
  date: z.date(),
  paymentMethod: z.enum(paymentMethods),
  notes: z.string().optional(),
});

// Zod validation for budgets
export const budgetSchema = z.object({
  name: z.string().min(3, "Budget name must be at least 3 characters long"),
  amount: z.number().int().positive("Budget amount must be positive"),
  period: z.enum(budgetPeriods),
  category: z.enum(expenseCategories).optional(),
  startDate: z.date(),
  endDate: z.date().optional(),
  isRecurring: z.boolean().default(true),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type ExpenseInput = z.infer<typeof expenseSchema>;

export type Budget = typeof budgets.$inferSelect;
export type InsertBudget = z.infer<typeof insertBudgetSchema>;
export type BudgetInput = z.infer<typeof budgetSchema>;

export type ExpenseCategory = typeof expenseCategories[number];
export type PaymentMethod = typeof paymentMethods[number];
export type BudgetPeriod = typeof budgetPeriods[number];
