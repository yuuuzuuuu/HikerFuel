import http from 'http';

// Create a minimal HTTP server with no dependencies
const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>FinTrack - Minimal Server</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
          body { font-family: sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
          h1 { color: #0284c7; }
          .card { background: #f9f9f9; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        </style>
      </head>
      <body>
        <h1>FinTrack Minimal Server</h1>
        <div class="card">
          <p>Berhasil menjalankan server minimal pada port ${PORT}.</p>
          <p>Waktu saat ini: ${new Date().toLocaleString()}</p>
          <p>Log: Server dibuat menggunakan modul HTTP bawaan Node.js tanpa dependencies.</p>
        </div>
      </body>
    </html>
  `);
});

// Try to open the port immediately - using port 3000 instead of 5000
console.log('Starting minimal HTTP server...');
const PORT = 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`Minimal server running on port ${PORT}`);
});