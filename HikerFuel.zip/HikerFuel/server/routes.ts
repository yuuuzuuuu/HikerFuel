import type { Express, Request, Response, NextFunction } from "express";
import { storage } from "./storage";
import { insertExpenseSchema, expenseSchema, insertBudgetSchema, budgetSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<void> {
  // Get all expenses
  app.get("/api/expenses", async (req: Request, res: Response) => {
    const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
    const category = req.query.category as string | undefined;
    
    let expenses;
    if (category) {
      expenses = await storage.getExpensesByCategory(category, userId);
    } else {
      expenses = await storage.getExpenses(userId);
    }
    
    res.json(expenses);
  });

  // Get an expense by ID
  app.get("/api/expenses/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "ID Pengeluaran tidak valid" });
    }
    
    const expense = await storage.getExpenseById(id);
    if (!expense) {
      return res.status(404).json({ message: "Pengeluaran tidak ditemukan" });
    }
    
    res.json(expense);
  });

  // Create a new expense
  app.post("/api/expenses", async (req: Request, res: Response) => {
    try {
      const validatedData = expenseSchema.parse(req.body);
      const expense = await storage.createExpense(validatedData);
      res.status(201).json(expense);
    } catch (error) {
      console.error("Error creating expense:", error);
      res.status(400).json({ 
        message: error instanceof Error 
          ? error.message 
          : "Data pengeluaran tidak valid" 
      });
    }
  });

  // Update an expense
  app.patch("/api/expenses/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "ID Pengeluaran tidak valid" });
    }
    
    try {
      // Partial validation of the update data
      const validationSchema = insertExpenseSchema.partial();
      const validatedData = validationSchema.parse(req.body);
      
      const updatedExpense = await storage.updateExpense(id, validatedData);
      if (!updatedExpense) {
        return res.status(404).json({ message: "Pengeluaran tidak ditemukan" });
      }
      
      res.json(updatedExpense);
    } catch (error) {
      console.error("Error updating expense:", error);
      res.status(400).json({ 
        message: error instanceof Error 
          ? error.message 
          : "Data perubahan tidak valid" 
      });
    }
  });

  // Delete an expense
  app.delete("/api/expenses/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "ID Pengeluaran tidak valid" });
    }
    
    const success = await storage.deleteExpense(id);
    if (!success) {
      return res.status(404).json({ message: "Pengeluaran tidak ditemukan" });
    }
    
    res.status(204).send();
  });
  
  // Get all budgets
  app.get("/api/budgets", async (req: Request, res: Response) => {
    const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
    const category = req.query.category as string | undefined;
    
    let budgets;
    if (category) {
      budgets = await storage.getBudgetsByCategory(category, userId);
    } else {
      budgets = await storage.getBudgets(userId);
    }
    
    res.json(budgets);
  });

  // Get a budget by ID
  app.get("/api/budgets/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "ID Budget tidak valid" });
    }
    
    const budget = await storage.getBudgetById(id);
    if (!budget) {
      return res.status(404).json({ message: "Budget tidak ditemukan" });
    }
    
    res.json(budget);
  });

  // Create a new budget
  app.post("/api/budgets", async (req: Request, res: Response) => {
    try {
      const validatedData = budgetSchema.parse(req.body);
      const budget = await storage.createBudget(validatedData);
      res.status(201).json(budget);
    } catch (error) {
      console.error("Error creating budget:", error);
      res.status(400).json({ 
        message: error instanceof Error 
          ? error.message 
          : "Data budget tidak valid" 
      });
    }
  });

  // Update a budget
  app.patch("/api/budgets/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "ID Budget tidak valid" });
    }
    
    try {
      // Partial validation of the update data
      const validationSchema = insertBudgetSchema.partial();
      const validatedData = validationSchema.parse(req.body);
      
      const updatedBudget = await storage.updateBudget(id, validatedData);
      if (!updatedBudget) {
        return res.status(404).json({ message: "Budget tidak ditemukan" });
      }
      
      res.json(updatedBudget);
    } catch (error) {
      console.error("Error updating budget:", error);
      res.status(400).json({ 
        message: error instanceof Error 
          ? error.message 
          : "Data perubahan tidak valid" 
      });
    }
  });

  // Delete a budget
  app.delete("/api/budgets/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "ID Budget tidak valid" });
    }
    
    const success = await storage.deleteBudget(id);
    if (!success) {
      return res.status(404).json({ message: "Budget tidak ditemukan" });
    }
    
    res.status(204).send();
  });
  
  // Get budget summary statistics
  app.get("/api/budget-summary", async (req: Request, res: Response) => {
    const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
    
    try {
      // Mendapatkan semua budget dan pengeluaran untuk pengguna
      const budgets = await storage.getBudgets(userId);
      const expenses = await storage.getExpenses(userId);
      
      // Membuat ringkasan per kategori
      const categorySummary: Record<string, { budget: number, spent: number, remaining: number }> = {};
      
      // Menghitung total budget per kategori
      budgets.forEach(budget => {
        const category = budget.category || 'lainnya';
        if (!categorySummary[category]) {
          categorySummary[category] = { budget: 0, spent: 0, remaining: 0 };
        }
        categorySummary[category].budget += budget.amount;
      });
      
      // Menghitung total pengeluaran per kategori
      expenses.forEach(expense => {
        const category = expense.category;
        if (!categorySummary[category]) {
          categorySummary[category] = { budget: 0, spent: 0, remaining: 0 };
        }
        categorySummary[category].spent += expense.amount;
      });
      
      // Menghitung sisa budget
      Object.keys(categorySummary).forEach(category => {
        categorySummary[category].remaining = 
          categorySummary[category].budget - categorySummary[category].spent;
      });
      
      // Total keseluruhan
      const totalBudget = budgets.reduce((sum, budget) => sum + budget.amount, 0);
      const totalSpent = expenses.reduce((sum, expense) => sum + expense.amount, 0);
      const totalRemaining = totalBudget - totalSpent;
      
      res.json({
        categorySummary,
        total: {
          budget: totalBudget,
          spent: totalSpent,
          remaining: totalRemaining
        }
      });
    } catch (error) {
      console.error("Error generating budget summary:", error);
      res.status(500).json({ message: "Gagal membuat ringkasan budget" });
    }
  });

  // No longer returning HTTP server
  return;
}
