import express from "express";
import path from "path";
import { createServer } from "http";
import { setupVite, log } from "./vite";
import { registerRoutes } from "./routes";

async function startServer() {
  // Create Express app
  const app = express();
  const server = createServer(app);
  
  // Setup Vite dev middleware or serve production build
  await setupVite(app, server);
  
  // Register API routes
  await registerRoutes(app);
  
  // Fallback: Serve a static HTML file if the React app fails to load
  app.get('/fallback', (_req, res) => {
    res.sendFile(path.join(process.cwd(), 'static-app.html'));
  });
  
  // API health check endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', message: 'FinTrack API is running' });
  });
  
  // Start server
  log('Starting FinTrack server...');
  const port = 5000;
  
  server.listen(port, "0.0.0.0", () => {
    log(`Server running and listening on port ${port}`);
  });
}

// Start the server
startServer().catch(err => {
  console.error("Failed to start server:", err);
});
