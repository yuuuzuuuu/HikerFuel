import { expenses, type Expense, type InsertExpense, budgets, type Budget, type InsertBudget, users, type User, type InsertUser } from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Expense operations
  getExpenses(userId?: number): Promise<Expense[]>;
  getExpenseById(id: number): Promise<Expense | undefined>;
  getExpensesByCategory(category: string, userId?: number): Promise<Expense[]>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  updateExpense(id: number, expense: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: number): Promise<boolean>;
  
  // Budget operations
  getBudgets(userId?: number): Promise<Budget[]>;
  getBudgetById(id: number): Promise<Budget | undefined>;
  getBudgetsByCategory(category: string, userId?: number): Promise<Budget[]>;
  createBudget(budget: InsertBudget): Promise<Budget>;
  updateBudget(id: number, budget: Partial<InsertBudget>): Promise<Budget | undefined>;
  deleteBudget(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private expenses: Map<number, Expense>;
  private budgets: Map<number, Budget>;
  private currentUserId: number;
  private currentExpenseId: number;
  private currentBudgetId: number;

  constructor() {
    this.users = new Map();
    this.expenses = new Map();
    this.budgets = new Map();
    this.currentUserId = 1;
    this.currentExpenseId = 1;
    this.currentBudgetId = 1;
    
    // Seed data
    this.seedData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Expense operations
  async getExpenses(userId?: number): Promise<Expense[]> {
    const expenses = Array.from(this.expenses.values());
    if (userId) {
      return expenses.filter(expense => expense.userId === userId);
    }
    return expenses;
  }

  async getExpenseById(id: number): Promise<Expense | undefined> {
    return this.expenses.get(id);
  }

  async getExpensesByCategory(category: string, userId?: number): Promise<Expense[]> {
    let expenses = Array.from(this.expenses.values());
    
    if (userId) {
      expenses = expenses.filter(expense => expense.userId === userId);
    }
    
    return expenses.filter(expense => expense.category === category);
  }

  async createExpense(insertExpense: InsertExpense): Promise<Expense> {
    const id = this.currentExpenseId++;
    const createdAt = new Date();
    
    // Create a new object with all required fields, setting defaults as needed
    const expense: Expense = {
      id,
      date: insertExpense.date || new Date(),
      userId: insertExpense.userId || null,
      amount: insertExpense.amount,
      description: insertExpense.description,
      category: insertExpense.category,
      paymentMethod: insertExpense.paymentMethod,
      notes: insertExpense.notes || null,
      createdAt: createdAt
    };
    
    this.expenses.set(id, expense);
    return expense;
  }

  async updateExpense(id: number, expenseUpdate: Partial<InsertExpense>): Promise<Expense | undefined> {
    const existingExpense = this.expenses.get(id);
    if (!existingExpense) {
      return undefined;
    }
    
    // Merge updates while ensuring the result has all required fields with correct types
    const updatedExpense: Expense = {
      ...existingExpense,
      date: expenseUpdate.date || existingExpense.date,
      description: expenseUpdate.description || existingExpense.description,
      amount: expenseUpdate.amount !== undefined ? expenseUpdate.amount : existingExpense.amount,
      category: expenseUpdate.category || existingExpense.category,
      paymentMethod: expenseUpdate.paymentMethod || existingExpense.paymentMethod,
      notes: expenseUpdate.notes !== undefined ? expenseUpdate.notes : existingExpense.notes
    };
    
    this.expenses.set(id, updatedExpense);
    return updatedExpense;
  }

  async deleteExpense(id: number): Promise<boolean> {
    return this.expenses.delete(id);
  }

  // Budget operations
  async getBudgets(userId?: number): Promise<Budget[]> {
    const budgets = Array.from(this.budgets.values());
    if (userId) {
      return budgets.filter(budget => budget.userId === userId);
    }
    return budgets;
  }

  async getBudgetById(id: number): Promise<Budget | undefined> {
    return this.budgets.get(id);
  }

  async getBudgetsByCategory(category: string, userId?: number): Promise<Budget[]> {
    let budgets = Array.from(this.budgets.values());
    
    if (userId) {
      budgets = budgets.filter(budget => budget.userId === userId);
    }
    
    return budgets.filter(budget => budget.category === category);
  }

  async createBudget(insertBudget: InsertBudget): Promise<Budget> {
    const id = this.currentBudgetId++;
    const createdAt = new Date();
    
    // Create a new object with all required fields, setting defaults as needed
    const budget: Budget = {
      id,
      name: insertBudget.name,
      userId: insertBudget.userId || null,
      amount: insertBudget.amount,
      category: insertBudget.category || null,
      period: insertBudget.period,
      startDate: insertBudget.startDate,
      endDate: insertBudget.endDate || null,
      isRecurring: insertBudget.isRecurring === undefined ? null : insertBudget.isRecurring,
      createdAt: createdAt
    };
    
    this.budgets.set(id, budget);
    return budget;
  }

  async updateBudget(id: number, budgetUpdate: Partial<InsertBudget>): Promise<Budget | undefined> {
    const existingBudget = this.budgets.get(id);
    if (!existingBudget) {
      return undefined;
    }
    
    // Merge updates while ensuring the result has all required fields with correct types
    const updatedBudget: Budget = {
      ...existingBudget,
      name: budgetUpdate.name || existingBudget.name,
      amount: budgetUpdate.amount !== undefined ? budgetUpdate.amount : existingBudget.amount,
      period: budgetUpdate.period || existingBudget.period,
      category: budgetUpdate.category !== undefined ? budgetUpdate.category : existingBudget.category,
      startDate: budgetUpdate.startDate || existingBudget.startDate,
      endDate: budgetUpdate.endDate !== undefined ? budgetUpdate.endDate : existingBudget.endDate,
      isRecurring: budgetUpdate.isRecurring !== undefined ? budgetUpdate.isRecurring : existingBudget.isRecurring
    };
    
    this.budgets.set(id, updatedBudget);
    return updatedBudget;
  }

  async deleteBudget(id: number): Promise<boolean> {
    return this.budgets.delete(id);
  }

  // Seed data
  private seedData() {
    // Seed a default user
    const defaultUser: InsertUser = {
      username: "pengguna",
      password: "password123"
    };
    const userId = this.currentUserId++;
    const user: User = { ...defaultUser, id: userId };
    this.users.set(userId, user);

    // Seed example budgets
    const budget1: InsertBudget = {
      userId: userId,
      name: "Budget Bulanan",
      amount: 5000000, // 5 juta rupiah
      period: "bulanan",
      startDate: new Date(),
      isRecurring: true
    };
    
    const budget2: InsertBudget = {
      userId: userId,
      name: "Anggaran Makanan",
      amount: 1500000, // 1.5 juta rupiah
      period: "bulanan",
      category: "makanan",
      startDate: new Date(),
      isRecurring: true
    };
    
    const budget3: InsertBudget = {
      userId: userId,
      name: "Budget Transportasi",
      amount: 800000, // 800 ribu rupiah
      period: "bulanan",
      category: "transportasi",
      startDate: new Date(),
      isRecurring: true
    };
    
    // Seed some expenses
    const expense1: InsertExpense = {
      userId: userId,
      amount: 75000, // 75 ribu rupiah
      description: "Makan siang di restoran",
      category: "makanan",
      date: new Date(),
      paymentMethod: "tunai"
    };
    
    const expense2: InsertExpense = {
      userId: userId,
      amount: 350000, // 350 ribu rupiah
      description: "Bensin mobil",
      category: "transportasi",
      date: new Date(),
      paymentMethod: "kartu-kredit"
    };
    
    const expense3: InsertExpense = {
      userId: userId,
      amount: 1200000, // 1.2 juta rupiah
      description: "Belanja bulanan",
      category: "belanja",
      date: new Date(),
      paymentMethod: "kartu-debit"
    };
    
    // Add budgets to storage
    [budget1, budget2, budget3].forEach(budget => {
      // Instead of spreading the object, create a new object with required fields
      const id = this.currentBudgetId++;
      const createdAt = new Date();
      
      const newBudget: Budget = {
        id,
        name: budget.name,
        userId: budget.userId || null,
        amount: budget.amount,
        category: budget.category || null,
        period: budget.period,
        startDate: budget.startDate,
        endDate: budget.endDate || null,
        isRecurring: budget.isRecurring === undefined ? null : budget.isRecurring,
        createdAt: createdAt
      };
      
      this.budgets.set(id, newBudget);
    });
    
    // Add expenses to storage
    [expense1, expense2, expense3].forEach(expense => {
      const id = this.currentExpenseId++;
      const createdAt = new Date();
      
      const newExpense: Expense = {
        id,
        date: expense.date || new Date(),
        userId: expense.userId || null,
        amount: expense.amount,
        description: expense.description,
        category: expense.category,
        paymentMethod: expense.paymentMethod,
        notes: expense.notes || null,
        createdAt: createdAt
      };
      
      this.expenses.set(id, newExpense);
    });
  }
}

export const storage = new MemStorage();
