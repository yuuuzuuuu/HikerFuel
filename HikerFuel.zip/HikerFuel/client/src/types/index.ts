// Types for expense categories, payment methods, and budget periods
export type ExpenseCategory =
  | "makanan"
  | "transportasi"
  | "belanja"
  | "hiburan"
  | "kesehatan"
  | "pendidikan"
  | "tagihan"
  | "lainnya";

export type PaymentMethod =
  | "tunai"
  | "kartu-kredit"
  | "kartu-debit"
  | "e-wallet"
  | "transfer-bank"
  | "lainnya";

export type BudgetPeriod = "harian" | "mingguan" | "bulanan" | "tahunan";

// Expense type
export interface Expense {
  id?: number;
  userId?: number;
  amount: number;
  description: string;
  category: ExpenseCategory;
  date: Date;
  paymentMethod: PaymentMethod;
  notes?: string;
  createdAt?: Date;
}

// Budget type for budget plans
export interface Budget {
  id?: number;
  userId?: number;
  name: string;
  amount: number; // Budget limit amount
  period: BudgetPeriod;
  category?: ExpenseCategory;
  startDate: Date;
  endDate?: Date;
  isRecurring: boolean;
  createdAt?: Date;
}

// Default empty expense
export const defaultExpense: Expense = {
  amount: 0,
  description: "",
  category: "lainnya",
  date: new Date(),
  paymentMethod: "tunai",
  notes: "",
};

// Default empty budget
export const defaultBudget: Budget = {
  name: "Budget Bulanan",
  amount: 1000000, // 1 juta rupiah dalam format IDR
  period: "bulanan",
  startDate: new Date(),
  isRecurring: true,
};
