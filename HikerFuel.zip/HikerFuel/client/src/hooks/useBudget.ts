import { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Budget, Expense, defaultBudget, defaultExpense } from '@/types';
import { useToast } from '@/hooks/use-toast';

export function useBudget() {
  const { toast } = useToast();
  const [currentUser, setCurrentUser] = useState<number | undefined>(1); // Default user ID for demo

  // Budget queries
  const {
    data: budgets = [],
    isLoading: isLoadingBudgets,
    error: budgetsError
  } = useQuery({
    queryKey: ['/api/budgets', { userId: currentUser }],
    queryFn: async () => {
      const res = await fetch(`/api/budgets?userId=${currentUser}`);
      if (!res.ok) throw new Error('Failed to fetch budgets');
      return res.json() as Promise<Budget[]>;
    }
  });

  // Expense queries
  const {
    data: expenses = [],
    isLoading: isLoadingExpenses,
    error: expensesError
  } = useQuery({
    queryKey: ['/api/expenses', { userId: currentUser }],
    queryFn: async () => {
      const res = await fetch(`/api/expenses?userId=${currentUser}`);
      if (!res.ok) throw new Error('Failed to fetch expenses');
      return res.json() as Promise<Expense[]>;
    }
  });

  // Budget summary query
  const {
    data: budgetSummary,
    isLoading: isLoadingSummary,
    error: summaryError
  } = useQuery({
    queryKey: ['/api/budget-summary', { userId: currentUser }],
    queryFn: async () => {
      const res = await fetch(`/api/budget-summary?userId=${currentUser}`);
      if (!res.ok) throw new Error('Failed to fetch budget summary');
      return res.json();
    }
  });

  // Budget mutations
  const createBudgetMutation = useMutation({
    mutationFn: async (newBudget: Partial<Budget>) => {
      // Ensure userId is set
      const budgetWithUser = {
        ...defaultBudget,
        ...newBudget,
        userId: currentUser
      };
      
      const res = await fetch('/api/budgets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(budgetWithUser),
      });
      
      if (!res.ok) throw new Error('Failed to create budget');
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/budgets'] });
      queryClient.invalidateQueries({ queryKey: ['/api/budget-summary'] });
      toast({
        title: "Budget dibuat",
        description: "Budget baru telah berhasil dibuat",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Gagal membuat budget: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const updateBudgetMutation = useMutation({
    mutationFn: async ({ id, budget }: { id: number; budget: Partial<Budget> }) => {
      const res = await fetch(`/api/budgets/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(budget),
      });
      
      if (!res.ok) throw new Error('Failed to update budget');
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/budgets'] });
      queryClient.invalidateQueries({ queryKey: ['/api/budget-summary'] });
      toast({
        title: "Budget diperbarui",
        description: "Budget telah berhasil diperbarui",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Gagal memperbarui budget: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const deleteBudgetMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/budgets/${id}`, {
        method: 'DELETE',
      });
      
      if (!res.ok) throw new Error('Failed to delete budget');
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/budgets'] });
      queryClient.invalidateQueries({ queryKey: ['/api/budget-summary'] });
      toast({
        title: "Budget dihapus",
        description: "Budget telah berhasil dihapus",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Gagal menghapus budget: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Expense mutations
  const createExpenseMutation = useMutation({
    mutationFn: async (newExpense: Partial<Expense>) => {
      // Ensure userId is set
      const expenseWithUser = {
        ...defaultExpense,
        ...newExpense,
        userId: currentUser
      };
      
      const res = await fetch('/api/expenses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(expenseWithUser),
      });
      
      if (!res.ok) throw new Error('Failed to create expense');
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/budget-summary'] });
      toast({
        title: "Pengeluaran dicatat",
        description: "Pengeluaran baru telah berhasil dicatat",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Gagal mencatat pengeluaran: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const updateExpenseMutation = useMutation({
    mutationFn: async ({ id, expense }: { id: number; expense: Partial<Expense> }) => {
      const res = await fetch(`/api/expenses/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(expense),
      });
      
      if (!res.ok) throw new Error('Failed to update expense');
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/budget-summary'] });
      toast({
        title: "Pengeluaran diperbarui",
        description: "Pengeluaran telah berhasil diperbarui",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Gagal memperbarui pengeluaran: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const deleteExpenseMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/expenses/${id}`, {
        method: 'DELETE',
      });
      
      if (!res.ok) throw new Error('Failed to delete expense');
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/budget-summary'] });
      toast({
        title: "Pengeluaran dihapus",
        description: "Pengeluaran telah berhasil dihapus",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Gagal menghapus pengeluaran: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Function to format currency in IDR
  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // Function to get budget summary data directly
  const getBudgetSummary = async () => {
    const res = await fetch(`/api/budget-summary?userId=${currentUser}`);
    if (!res.ok) throw new Error('Failed to fetch budget summary');
    return res.json();
  };

  return {
    // State
    currentUser,
    setCurrentUser,
    
    // Data
    budgets,
    expenses,
    budgetSummary,
    
    // Loading states
    isLoadingBudgets,
    isLoadingExpenses,
    isLoadingSummary,
    
    // Errors
    budgetsError,
    expensesError,
    summaryError,
    
    // Budget mutations
    createBudget: createBudgetMutation.mutate,
    isCreatingBudget: createBudgetMutation.isPending,
    updateBudget: updateBudgetMutation.mutate,
    isUpdatingBudget: updateBudgetMutation.isPending,
    deleteBudget: deleteBudgetMutation.mutate,
    isDeletingBudget: deleteBudgetMutation.isPending,
    
    // Expense mutations
    createExpense: createExpenseMutation.mutate,
    isCreatingExpense: createExpenseMutation.isPending,
    updateExpense: updateExpenseMutation.mutate,
    isUpdatingExpense: updateExpenseMutation.isPending,
    deleteExpense: deleteExpenseMutation.mutate,
    isDeletingExpense: deleteExpenseMutation.isPending,
    
    // Data fetching functions
    getBudgetSummary,
    
    // Helpers
    formatCurrency,
  };
}