import { useState, useCallback } from "react";
import { MealPlan, defaultMealPlan, MealType, Meal, ActivityLevel } from "@/types";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function useMealPlan() {
  const [mealPlan, setMealPlan] = useState<MealPlan>({ ...defaultMealPlan });
  const { toast } = useToast();

  // Update meal plan
  const updateMealPlan = useCallback((updates: Partial<MealPlan>) => {
    setMealPlan((prev) => ({ ...prev, ...updates }));
  }, []);

  // Get all meals for a specific day
  const getMealsForDay = useCallback(
    (dayIndex: number) => {
      return mealPlan.meals.filter((meal) => meal.dayIndex === dayIndex);
    },
    [mealPlan.meals]
  );

  // Add a meal to a specific day
  const addMealToDay = useCallback(
    (dayIndex: number, mealType: MealType, recipeId: number) => {
      setMealPlan((prev) => {
        // Filter out any existing meal of this type for this day
        const filteredMeals = prev.meals.filter(
          (meal) => !(meal.dayIndex === dayIndex && meal.mealType === mealType)
        );

        // Add the new meal
        return {
          ...prev,
          meals: [...filteredMeals, { dayIndex, mealType, recipeId }],
        };
      });
    },
    []
  );

  // Remove a meal from a specific day
  const removeMealFromDay = useCallback(
    (dayIndex: number, mealType: MealType) => {
      setMealPlan((prev) => {
        return {
          ...prev,
          meals: prev.meals.filter(
            (meal) => !(meal.dayIndex === dayIndex && meal.mealType === mealType)
          ),
        };
      });
    },
    []
  );

  // Calculate calorie needs based on activity level
  const calculateCalorieNeeds = useCallback(
    (activityLevel: ActivityLevel): number => {
      const baseCalories = 2000;
      
      switch (activityLevel) {
        case "low":
          return baseCalories + 500;
        case "moderate":
          return baseCalories + 800;
        case "high":
          return baseCalories + 1200;
        case "extreme":
          return baseCalories + 1600;
        default:
          return baseCalories + 800; // Default to moderate
      }
    },
    []
  );

  // Generate a meal plan based on current settings
  const generateMealPlan = useCallback(async () => {
    try {
      // Calculate proper calorie needs if not set
      if (mealPlan.dailyCalories === defaultMealPlan.dailyCalories) {
        const calculatedCalories = calculateCalorieNeeds(mealPlan.activityLevel);
        updateMealPlan({ dailyCalories: calculatedCalories });
      }

      // For a new meal plan, make a POST request
      if (!mealPlan.id) {
        // In a real app with authentication, we'd include the userId here
        const response = await apiRequest("POST", "/api/meal-plans", {
          ...mealPlan,
          // Ensure calories and macros are set
          dailyCalories: mealPlan.dailyCalories || calculateCalorieNeeds(mealPlan.activityLevel),
          proteinPercentage: mealPlan.proteinPercentage || 25,
          carbsPercentage: mealPlan.carbsPercentage || 55,
          fatPercentage: mealPlan.fatPercentage || 20,
        });

        const savedMealPlan = await response.json();
        updateMealPlan({ id: savedMealPlan.id });
        
        toast({
          title: "Meal Plan Generated",
          description: "Your meal plan has been created successfully.",
        });
        
        return savedMealPlan;
      } else {
        // For an existing meal plan, make a PATCH request
        const response = await apiRequest(
          "PATCH",
          `/api/meal-plans/${mealPlan.id}`,
          mealPlan
        );

        const updatedMealPlan = await response.json();
        updateMealPlan(updatedMealPlan);
        
        toast({
          title: "Meal Plan Updated",
          description: "Your meal plan has been updated successfully.",
        });
        
        return updatedMealPlan;
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save meal plan. Please try again.",
        variant: "destructive",
      });
      console.error("Error generating meal plan:", error);
    }
  }, [mealPlan, calculateCalorieNeeds, updateMealPlan, toast]);

  // Calculate total nutrition for day
  const calculateDailyNutrition = useCallback(
    (dayIndex: number, recipes: any[]) => {
      const dayMeals = getMealsForDay(dayIndex);
      if (!dayMeals.length || !recipes.length) return null;

      let totalCalories = 0;
      let totalProtein = 0;
      let totalCarbs = 0;
      let totalFat = 0;

      dayMeals.forEach((meal) => {
        const recipe = recipes.find((r) => r.id === meal.recipeId);
        if (recipe) {
          totalCalories += recipe.calories;
          totalProtein += recipe.protein;
          totalCarbs += recipe.carbs;
          totalFat += recipe.fat;
        }
      });

      return {
        calories: totalCalories,
        protein: totalProtein,
        carbs: totalCarbs,
        fat: totalFat,
      };
    },
    [getMealsForDay]
  );

  return {
    mealPlan,
    updateMealPlan,
    getMealsForDay,
    addMealToDay,
    removeMealFromDay,
    generateMealPlan,
    calculateDailyNutrition,
  };
}
