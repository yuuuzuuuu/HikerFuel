import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Budgets from "@/pages/Budgets";
import Expenses from "@/pages/Expenses";
import Report from "@/pages/Report";
import Profile from "@/pages/Profile";
import BankAccounts from "@/pages/BankAccounts";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import SplashScreen from "@/components/SplashScreen";
import { NotificationProvider } from "./context/NotificationContext";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/budgets" component={Budgets} />
      <Route path="/expenses" component={Expenses} />
      <Route path="/report" component={Report} />
      <Route path="/profile" component={Profile} />
      <Route path="/bank-accounts" component={BankAccounts} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <NotificationProvider>
        <div className="min-h-screen flex flex-col">
          <SplashScreen />
          <Header />
          <div className="flex-grow pb-16 md:pb-0">
            <Router />
          </div>
          <Footer className="hidden md:block" />
        </div>
        <Toaster />
      </NotificationProvider>
    </QueryClientProvider>
  );
}

export default App;
