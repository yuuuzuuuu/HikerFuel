import { useState } from "react";
import { useLocation } from "wouter";
import { useBudget } from "@/hooks/useBudget";
import { Budget, BudgetPeriod, ExpenseCategory } from "@/types";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { 
  CircleDollarSign, 
  ArrowLeft, 
  Plus, 
  Calendar, 
  CalendarClock,
  Edit,
  Trash,
} from "lucide-react";

export default function Budgets() {
  const [, navigate] = useLocation();
  const { 
    budgets, 
    isLoadingBudgets, 
    formatCurrency,
    createBudget,
    isCreatingBudget,
    updateBudget,
    isUpdatingBudget,
    deleteBudget,
    isDeletingBudget
  } = useBudget();

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [currentBudget, setCurrentBudget] = useState<Budget | null>(null);
  
  const [newBudget, setNewBudget] = useState<Partial<Budget>>({
    name: "",
    amount: 0,
    period: "bulanan",
    startDate: new Date(),
    isRecurring: true
  });

  const handleAddBudget = () => {
    createBudget(newBudget);
    setIsAddDialogOpen(false);
    setNewBudget({
      name: "",
      amount: 0,
      period: "bulanan",
      startDate: new Date(),
      isRecurring: true
    });
  };

  const handleEditBudget = () => {
    if (currentBudget && currentBudget.id) {
      // Omit id to avoid sending it in the update
      const { id, ...budgetUpdate } = currentBudget;
      updateBudget({ id, budget: budgetUpdate });
      setIsEditDialogOpen(false);
      setCurrentBudget(null);
    }
  };

  const handleDeleteBudget = () => {
    if (currentBudget && currentBudget.id) {
      deleteBudget(currentBudget.id);
      setIsDeleteDialogOpen(false);
      setCurrentBudget(null);
    }
  };

  // Helper for formatting period display
  const formatPeriod = (period: BudgetPeriod) => {
    switch (period) {
      case "harian": return "Harian";
      case "mingguan": return "Mingguan";
      case "bulanan": return "Bulanan";
      case "tahunan": return "Tahunan";
      default: return period;
    }
  };

  return (
    <main className="container mx-auto px-4 py-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            className="h-9 w-9 p-0"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl sm:text-2xl font-bold">Kelola Budget</h1>
        </div>
        <Button 
          onClick={() => setIsAddDialogOpen(true)}
          className="flex items-center gap-2 w-full sm:w-auto"
        >
          <Plus className="h-4 w-4" />
          Tambah Budget
        </Button>
      </div>

      {/* Budget Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {isLoadingBudgets ? (
          // Loading state
          Array(3).fill(0).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <CardHeader className="pb-2">
                <Skeleton className="h-5 w-3/4 mb-2" />
                <Skeleton className="h-8 w-1/2" />
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                </div>
                <div className="flex justify-end mt-4">
                  <Skeleton className="h-9 w-20 mr-2" />
                  <Skeleton className="h-9 w-20" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : budgets.length === 0 ? (
          // Empty state
          <div className="col-span-full flex flex-col items-center justify-center py-12 border border-dashed rounded-lg">
            <CircleDollarSign className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Belum ada budget</h3>
            <p className="text-muted-foreground mb-4 text-center max-w-md">
              Buat budget baru untuk membantu Anda melimit pengeluaran dan mencapai tujuan finansial.
            </p>
            <Button 
              onClick={() => setIsAddDialogOpen(true)}
              className="flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              Tambah Budget
            </Button>
          </div>
        ) : (
          // Content
          budgets.map(budget => (
            <Card key={budget.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-xl">{budget.name}</CardTitle>
                  <div className="flex gap-1">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => {
                        setCurrentBudget(budget);
                        setIsEditDialogOpen(true);
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => {
                        setCurrentBudget(budget);
                        setIsDeleteDialogOpen(true);
                      }}
                    >
                      <Trash className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="text-2xl font-bold">{formatCurrency(budget.amount)}</div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col gap-1 text-sm text-muted-foreground mb-3">
                  <div className="flex items-center gap-2">
                    <CalendarClock className="h-4 w-4 flex-shrink-0" />
                    <span className="truncate">
                      Budget {formatPeriod(budget.period as BudgetPeriod)}
                      {budget.isRecurring ? " (Berulang)" : ""}
                    </span>
                  </div>
                  {budget.category && (
                    <div className="flex items-center gap-2">
                      <span className="truncate">Kategori: {budget.category}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Add Budget Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-[95%] sm:max-w-[425px] p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-lg sm:text-xl">Tambah Budget Baru</DialogTitle>
            <DialogDescription>
              Isi detail budget baru untuk melimit pengeluaran Anda.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
              <Label htmlFor="name" className="sm:text-right">
                Nama
              </Label>
              <Input
                id="name"
                placeholder="Contoh: Budget Bulanan"
                className="sm:col-span-3"
                value={newBudget.name}
                onChange={(e) => setNewBudget({ ...newBudget, name: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
              <Label htmlFor="amount" className="sm:text-right">
                Jumlah
              </Label>
              <Input
                id="amount"
                type="number"
                placeholder="0"
                className="sm:col-span-3"
                value={newBudget.amount || ''}
                onChange={(e) => setNewBudget({ ...newBudget, amount: parseInt(e.target.value) || 0 })}
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
              <Label htmlFor="period" className="sm:text-right">
                Periode
              </Label>
              <Select 
                value={newBudget.period as string}
                onValueChange={(value) => setNewBudget({ ...newBudget, period: value as BudgetPeriod })}
              >
                <SelectTrigger className="sm:col-span-3">
                  <SelectValue placeholder="Pilih periode" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="harian">Harian</SelectItem>
                  <SelectItem value="mingguan">Mingguan</SelectItem>
                  <SelectItem value="bulanan">Bulanan</SelectItem>
                  <SelectItem value="tahunan">Tahunan</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
              <Label htmlFor="category" className="sm:text-right">
                Kategori
              </Label>
              <Select 
                value={newBudget.category as string || ''}
                onValueChange={(value) => setNewBudget({ ...newBudget, category: value as ExpenseCategory })}
              >
                <SelectTrigger className="sm:col-span-3">
                  <SelectValue placeholder="Semua kategori" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="makanan">Makanan</SelectItem>
                  <SelectItem value="transportasi">Transportasi</SelectItem>
                  <SelectItem value="belanja">Belanja</SelectItem>
                  <SelectItem value="hiburan">Hiburan</SelectItem>
                  <SelectItem value="kesehatan">Kesehatan</SelectItem>
                  <SelectItem value="pendidikan">Pendidikan</SelectItem>
                  <SelectItem value="tagihan">Tagihan</SelectItem>
                  <SelectItem value="lainnya">Lainnya</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button 
              variant="outline" 
              onClick={() => setIsAddDialogOpen(false)}
              className="w-full sm:w-auto"
            >
              Batal
            </Button>
            <Button 
              onClick={handleAddBudget}
              disabled={isCreatingBudget || !newBudget.name || !newBudget.amount}
              className="w-full sm:w-auto"
            >
              {isCreatingBudget ? "Menyimpan..." : "Simpan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Budget Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-[95%] sm:max-w-[425px] p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-lg sm:text-xl">Edit Budget</DialogTitle>
            <DialogDescription>
              Ubah detail budget Anda.
            </DialogDescription>
          </DialogHeader>
          {currentBudget && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
                <Label htmlFor="edit-name" className="sm:text-right">
                  Nama
                </Label>
                <Input
                  id="edit-name"
                  className="sm:col-span-3"
                  value={currentBudget.name}
                  onChange={(e) => setCurrentBudget({ ...currentBudget, name: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
                <Label htmlFor="edit-amount" className="sm:text-right">
                  Jumlah
                </Label>
                <Input
                  id="edit-amount"
                  type="number"
                  className="sm:col-span-3"
                  value={currentBudget.amount}
                  onChange={(e) => setCurrentBudget({ ...currentBudget, amount: parseInt(e.target.value) || 0 })}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
                <Label htmlFor="edit-period" className="sm:text-right">
                  Periode
                </Label>
                <Select 
                  value={currentBudget.period as string}
                  onValueChange={(value) => setCurrentBudget({ ...currentBudget, period: value as BudgetPeriod })}
                >
                  <SelectTrigger className="sm:col-span-3">
                    <SelectValue placeholder="Pilih periode" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="harian">Harian</SelectItem>
                    <SelectItem value="mingguan">Mingguan</SelectItem>
                    <SelectItem value="bulanan">Bulanan</SelectItem>
                    <SelectItem value="tahunan">Tahunan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
                <Label htmlFor="edit-category" className="sm:text-right">
                  Kategori
                </Label>
                <Select 
                  value={currentBudget.category as string || ''}
                  onValueChange={(value) => setCurrentBudget({ ...currentBudget, category: value as ExpenseCategory })}
                >
                  <SelectTrigger className="sm:col-span-3">
                    <SelectValue placeholder="Semua kategori" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="makanan">Makanan</SelectItem>
                    <SelectItem value="transportasi">Transportasi</SelectItem>
                    <SelectItem value="belanja">Belanja</SelectItem>
                    <SelectItem value="hiburan">Hiburan</SelectItem>
                    <SelectItem value="kesehatan">Kesehatan</SelectItem>
                    <SelectItem value="pendidikan">Pendidikan</SelectItem>
                    <SelectItem value="tagihan">Tagihan</SelectItem>
                    <SelectItem value="lainnya">Lainnya</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button 
              variant="outline" 
              onClick={() => setIsEditDialogOpen(false)}
              className="w-full sm:w-auto"
            >
              Batal
            </Button>
            <Button 
              onClick={handleEditBudget}
              disabled={isUpdatingBudget || !currentBudget?.name || !currentBudget?.amount}
              className="w-full sm:w-auto"
            >
              {isUpdatingBudget ? "Memperbarui..." : "Perbarui"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Budget Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="max-w-[95%] sm:max-w-[425px] p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-lg sm:text-xl">Hapus Budget</DialogTitle>
            <DialogDescription>
              Apakah Anda yakin ingin menghapus budget ini? Tindakan ini tidak dapat dibatalkan.
            </DialogDescription>
          </DialogHeader>
          {currentBudget && (
            <div className="py-4">
              <p className="font-medium">{currentBudget.name}</p>
              <p>{formatCurrency(currentBudget.amount)}</p>
              <p className="text-sm text-muted-foreground">{formatPeriod(currentBudget.period as BudgetPeriod)}</p>
            </div>
          )}
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button 
              variant="outline" 
              onClick={() => setIsDeleteDialogOpen(false)}
              className="w-full sm:w-auto"
            >
              Batal
            </Button>
            <Button 
              variant="destructive"
              onClick={handleDeleteBudget}
              disabled={isDeletingBudget}
              className="w-full sm:w-auto"
            >
              {isDeletingBudget ? "Menghapus..." : "Hapus"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </main>
  );
}