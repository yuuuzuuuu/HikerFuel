import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { CreditCard, Plus, RefreshCw, ChevronRight, Clock } from "lucide-react";
import BankConnection from "@/components/BankConnection";

// Komponen untuk menampilkan saldo rekening
const AccountCard = ({ 
  bank, 
  accountNumber, 
  balance, 
  type, 
  lastUpdated 
}: { 
  bank: string; 
  accountNumber: string; 
  balance: number; 
  type: string;
  lastUpdated: string;
}) => {
  const formatBalance = new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0
  }).format(balance);

  return (
    <Card className="mb-4 overflow-hidden">
      <CardContent className="p-0">
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="font-semibold text-lg text-foreground">{bank}</h3>
              <div className="text-sm text-muted-foreground">
                {accountNumber.replace(/(\d{4})/g, '$1 ').trim()}
              </div>
            </div>
            <Badge variant={type === 'Tabungan' ? 'default' : type === 'Giro' ? 'secondary' : 'outline'}>
              {type}
            </Badge>
          </div>
          
          <div className="mt-6">
            <div className="text-sm text-muted-foreground mb-1">Saldo</div>
            <div className="text-2xl font-bold text-foreground">{formatBalance}</div>
          </div>
          
          <div className="flex items-center mt-4 text-xs text-muted-foreground">
            <Clock className="h-3 w-3 mr-1" />
            <span>Terakhir diperbarui: {lastUpdated}</span>
          </div>
        </div>
        
        <div className="border-t p-3 bg-secondary/20 flex justify-between items-center">
          <Button variant="ghost" size="sm" className="text-xs">
            <RefreshCw className="h-3 w-3 mr-1.5" />
            Perbarui Saldo
          </Button>
          
          <Button variant="ghost" size="sm" className="text-xs">
            Lihat Transaksi
            <ChevronRight className="h-3 w-3 ml-1.5" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

// Data contoh (simulasi)
const bankAccounts = [
  {
    id: 1,
    bank: "Bank Central Asia",
    accountNumber: "1234567890",
    balance: 5470000,
    type: "Tabungan",
    lastUpdated: "Hari ini, 10:25 WIB"
  },
  {
    id: 2,
    bank: "Bank Mandiri",
    accountNumber: "9876543210",
    balance: 3250000,
    type: "Giro",
    lastUpdated: "Kemarin, 15:30 WIB"
  }
];

const eWallets = [
  {
    id: 1,
    bank: "GoPay",
    accountNumber: "0812xxxxxxxx",
    balance: 235000,
    type: "E-Wallet",
    lastUpdated: "Hari ini, 08:15 WIB"
  },
  {
    id: 2,
    bank: "OVO",
    accountNumber: "0857xxxxxxxx",
    balance: 128500,
    type: "E-Wallet",
    lastUpdated: "Kemarin, 20:42 WIB"
  }
];

const BankAccounts = () => {
  const [openDialog, setOpenDialog] = useState(false);
  const [activeTab, setActiveTab] = useState<string>("bank");
  const [location] = useLocation();

  useEffect(() => {
    // Cek jika URL memiliki parameter tab=ewallet
    if (location.includes("?tab=ewallet")) {
      setActiveTab("ewallet");
    }
  }, [location]);

  const handleConnect = () => {
    setOpenDialog(false);
    // Di sini bisa ditambahkan logika untuk memperbarui daftar rekening
  };

  const handleCancel = () => {
    setOpenDialog(false);
  };

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-1">Rekening & Saldo</h1>
          <p className="text-muted-foreground">Kelola semua rekening bank dan e-wallet Anda</p>
        </div>
        
        <Dialog open={openDialog} onOpenChange={setOpenDialog}>
          <DialogTrigger asChild>
            <Button className="mt-4 md:mt-0">
              <Plus className="h-4 w-4 mr-2" />
              Tambah Rekening
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[550px] p-0">
            <BankConnection onConnect={handleConnect} onCancel={handleCancel} />
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="bank">Rekening Bank</TabsTrigger>
          <TabsTrigger value="ewallet">E-Wallet</TabsTrigger>
        </TabsList>
        
        <TabsContent value="bank">
          {bankAccounts.length > 0 ? (
            <div>
              {bankAccounts.map(account => (
                <AccountCard
                  key={account.id}
                  bank={account.bank}
                  accountNumber={account.accountNumber}
                  balance={account.balance}
                  type={account.type}
                  lastUpdated={account.lastUpdated}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="rounded-full bg-gray-100 p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                <CreditCard className="h-6 w-6 text-gray-500" />
              </div>
              <h3 className="text-lg font-medium mb-2">Belum ada rekening bank</h3>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                Hubungkan rekening bank Anda untuk melihat saldo dan memantau transaksi secara otomatis.
              </p>
              <Button onClick={() => setOpenDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Tambah Rekening Bank
              </Button>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="ewallet">
          {eWallets.length > 0 ? (
            <div>
              {eWallets.map(wallet => (
                <AccountCard
                  key={wallet.id}
                  bank={wallet.bank}
                  accountNumber={wallet.accountNumber}
                  balance={wallet.balance}
                  type={wallet.type}
                  lastUpdated={wallet.lastUpdated}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="rounded-full bg-gray-100 p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                <CreditCard className="h-6 w-6 text-gray-500" />
              </div>
              <h3 className="text-lg font-medium mb-2">Belum ada E-Wallet</h3>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                Hubungkan e-wallet Anda untuk melihat saldo dan memantau transaksi secara otomatis.
              </p>
              <Button onClick={() => setOpenDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Tambah E-Wallet
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>

      <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-blue-800">
        <p className="font-medium mb-1">Catatan:</p>
        <p>
          Data yang ditampilkan di sini adalah data simulasi untuk tujuan demonstrasi. 
          Untuk mengintegrasikan dengan rekening bank sungguhan, diperlukan API resmi dari bank tersebut.
        </p>
      </div>
    </div>
  );
};

export default BankAccounts;