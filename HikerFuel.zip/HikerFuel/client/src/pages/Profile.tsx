import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { ToastAction } from "@/components/ui/toast";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function Profile() {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  
  // Mock user data, in a real application this would come from your API/auth system
  const [userData, setUserData] = useState({
    id: 1,
    username: "pengguna",
    name: "Pengguna BudgetKu",
    email: "pengguna@example.com",
    joinDate: new Date("2023-01-15"),
    budgetCount: 3,
    expenseCount: 15
  });
  
  const [formData, setFormData] = useState({
    name: userData.name,
    email: userData.email,
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleSaveProfile = () => {
    setUserData(prev => ({
      ...prev,
      name: formData.name,
      email: formData.email
    }));
    
    setIsEditing(false);
    
    toast({
      title: "Profil diperbarui",
      description: "Informasi profil Anda telah berhasil diperbarui.",
      variant: "default"
    });
  };
  
  const handleChangePassword = () => {
    if (formData.newPassword !== formData.confirmPassword) {
      toast({
        title: "Password tidak cocok",
        description: "Password baru dan konfirmasi password harus sama.",
        variant: "destructive"
      });
      return;
    }
    
    if (formData.newPassword.length < 8) {
      toast({
        title: "Password terlalu pendek",
        description: "Password harus minimal 8 karakter.",
        variant: "destructive"
      });
      return;
    }
    
    // In a real app, you would send this to your API
    toast({
      title: "Password diperbarui",
      description: "Password Anda telah berhasil diperbarui.",
      variant: "default"
    });
    
    // Reset password fields
    setFormData(prev => ({
      ...prev,
      currentPassword: "",
      newPassword: "",
      confirmPassword: ""
    }));
  };

  // Format the join date
  const formatJoinDate = (date: Date) => {
    return new Intl.DateTimeFormat("id-ID", {
      year: "numeric",
      month: "long",
      day: "numeric"
    }).format(date);
  };

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl sm:text-3xl font-bold mb-6">Profil Pengguna</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-1">
          <Card>
            <CardContent className="pt-6 flex flex-col items-center">
              <Avatar className="h-20 w-20 sm:h-24 sm:w-24 mb-4">
                <AvatarImage src="" alt={userData.name} />
                <AvatarFallback className="text-xl sm:text-2xl">{userData.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <h2 className="text-xl font-bold text-center">{userData.name}</h2>
              <p className="text-muted-foreground mb-4 text-center break-all">{userData.email}</p>
              <Badge variant="secondary">Pengguna</Badge>
              <div className="w-full mt-6">
                <p className="text-sm text-muted-foreground text-center sm:text-left">
                  Bergabung sejak {formatJoinDate(userData.joinDate)}
                </p>
                <Separator className="my-4" />
                <div className="flex justify-between text-sm">
                  <span>Budget</span>
                  <span className="font-medium">{userData.budgetCount}</span>
                </div>
                <div className="flex justify-between text-sm mt-2">
                  <span>Pengeluaran</span>
                  <span className="font-medium">{userData.expenseCount}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="md:col-span-3">
          <Tabs defaultValue="profile" className="w-full">
            <TabsList className="mb-4 w-full flex overflow-auto">
              <TabsTrigger value="profile" className="flex-1">Informasi Profil</TabsTrigger>
              <TabsTrigger value="security" className="flex-1">Keamanan</TabsTrigger>
              <TabsTrigger value="preferences" className="flex-1">Preferensi</TabsTrigger>
            </TabsList>
            
            <TabsContent value="profile">
              <Card>
                <CardHeader className="px-4 sm:px-6">
                  <CardTitle className="text-lg sm:text-xl">Informasi Profil</CardTitle>
                  <CardDescription>
                    Kelola informasi profil Anda dan bagaimana mereka ditampilkan
                  </CardDescription>
                </CardHeader>
                <CardContent className="px-4 sm:px-6 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nama</Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <Input
                      id="username"
                      value={userData.username}
                      disabled
                    />
                    <p className="text-sm text-muted-foreground">
                      Username tidak dapat diubah
                    </p>
                  </div>
                </CardContent>
                <CardFooter className="px-4 sm:px-6 flex flex-col sm:flex-row sm:justify-between gap-2">
                  {isEditing ? (
                    <>
                      <Button variant="outline" onClick={() => setIsEditing(false)} className="w-full sm:w-auto">Batal</Button>
                      <Button onClick={handleSaveProfile} className="w-full sm:w-auto">Simpan Perubahan</Button>
                    </>
                  ) : (
                    <Button onClick={() => setIsEditing(true)} className="w-full sm:w-auto">Edit Profil</Button>
                  )}
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="security">
              <Card>
                <CardHeader className="px-4 sm:px-6">
                  <CardTitle className="text-lg sm:text-xl">Keamanan</CardTitle>
                  <CardDescription>
                    Kelola pengaturan keamanan akun Anda
                  </CardDescription>
                </CardHeader>
                <CardContent className="px-4 sm:px-6 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="currentPassword">Password Saat Ini</Label>
                    <Input
                      id="currentPassword"
                      name="currentPassword"
                      type="password"
                      value={formData.currentPassword}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="newPassword">Password Baru</Label>
                    <Input
                      id="newPassword"
                      name="newPassword"
                      type="password"
                      value={formData.newPassword}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Konfirmasi Password Baru</Label>
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      value={formData.confirmPassword}
                      onChange={handleInputChange}
                    />
                  </div>
                </CardContent>
                <CardFooter className="px-4 sm:px-6">
                  <Button onClick={handleChangePassword} className="w-full sm:w-auto">Ubah Password</Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="preferences">
              <Card>
                <CardHeader className="px-4 sm:px-6">
                  <CardTitle className="text-lg sm:text-xl">Preferensi</CardTitle>
                  <CardDescription>
                    Kustomisasi pengalaman penggunaan BudgetKu Anda
                  </CardDescription>
                </CardHeader>
                <CardContent className="px-4 sm:px-6 space-y-4">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Notifikasi</h3>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                      <div>
                        <Label htmlFor="notif-email">Notifikasi Email</Label>
                        <p className="text-sm text-muted-foreground">
                          Terima notifikasi tentang perubahan budget dan laporan melalui email
                        </p>
                      </div>
                      <div className="flex items-center space-x-2 self-start sm:self-center">
                        <Button variant="outline" size="sm">On</Button>
                        <Button variant="outline" size="sm">Off</Button>
                      </div>
                    </div>
                    <Separator />
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                      <div>
                        <Label htmlFor="notif-browser">Notifikasi Browser</Label>
                        <p className="text-sm text-muted-foreground">
                          Terima notifikasi saat membuka aplikasi BudgetKu
                        </p>
                      </div>
                      <div className="flex items-center space-x-2 self-start sm:self-center">
                        <Button variant="outline" size="sm">On</Button>
                        <Button variant="outline" size="sm">Off</Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="px-4 sm:px-6">
                  <Button className="w-full sm:w-auto">Simpan Preferensi</Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}