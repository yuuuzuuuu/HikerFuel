import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from "recharts";
import { useQuery } from "@tanstack/react-query";
import { useBudget } from "@/hooks/useBudget";
import { ExpenseCategory } from "@/types";

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#a480cf", "#3a86ff", "#fb5607", "#ff006e"];

export default function Report() {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [period, setPeriod] = useState<string>("bulanan");
  const [reportType, setReportType] = useState<string>("pengeluaran");
  
  const { getBudgetSummary } = useBudget();
  
  // Get budget summary data from API
  const { data: summaryData, isLoading } = useQuery({
    queryKey: ["/api/budget-summary"],
    queryFn: getBudgetSummary,
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  // Generate chart data based on the summary data
  const generateChartData = () => {
    if (!summaryData || !summaryData.categorySummary) return [];
    
    const data = [];
    for (const [category, values] of Object.entries(summaryData.categorySummary)) {
      const { budget, spent } = values as { budget: number; spent: number };
      data.push({
        name: getCategoryLabel(category as ExpenseCategory),
        budget,
        spent,
      });
    }
    return data;
  };

  // Generate pie chart data for expenses by category
  const generatePieData = () => {
    if (!summaryData || !summaryData.categorySummary) return [];
    
    const data = [];
    for (const [category, values] of Object.entries(summaryData.categorySummary)) {
      const { spent } = values as { budget: number; spent: number };
      if (spent > 0) {
        data.push({
          name: getCategoryLabel(category as ExpenseCategory),
          value: spent,
        });
      }
    }
    return data;
  };

  const getCategoryLabel = (category: ExpenseCategory) => {
    const labels: Record<ExpenseCategory, string> = {
      makanan: "Makanan",
      transportasi: "Transportasi",
      belanja: "Belanja",
      hiburan: "Hiburan",
      kesehatan: "Kesehatan",
      pendidikan: "Pendidikan",
      tagihan: "Tagihan",
      lainnya: "Lainnya",
    };
    return labels[category] || category;
  };

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl sm:text-3xl font-bold mb-6">Laporan Keuangan</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader className="px-4 sm:px-6">
            <CardTitle className="text-lg sm:text-xl">Filter Laporan</CardTitle>
            <CardDescription>Atur jenis dan periode laporan yang ingin ditampilkan</CardDescription>
          </CardHeader>
          <CardContent className="px-4 sm:px-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="reportType">Jenis Laporan</Label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger id="reportType">
                  <SelectValue placeholder="Pilih jenis laporan" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pengeluaran">Pengeluaran</SelectItem>
                  <SelectItem value="budget">Budget</SelectItem>
                  <SelectItem value="perbandingan">Perbandingan Budget & Pengeluaran</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="period">Periode</Label>
              <Select value={period} onValueChange={setPeriod}>
                <SelectTrigger id="period">
                  <SelectValue placeholder="Pilih periode" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="harian">Harian</SelectItem>
                  <SelectItem value="mingguan">Mingguan</SelectItem>
                  <SelectItem value="bulanan">Bulanan</SelectItem>
                  <SelectItem value="tahunan">Tahunan</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>Tanggal</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left">
                    {date ? format(date, "PPP") : "Pilih tanggal"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <Button className="w-full">Generate Laporan</Button>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="px-4 sm:px-6">
            <CardTitle className="text-lg sm:text-xl">Ringkasan</CardTitle>
            <CardDescription>Ringkasan keuangan {period}</CardDescription>
          </CardHeader>
          <CardContent className="px-4 sm:px-6 space-y-4">
            {isLoading ? (
              <p>Memuat data...</p>
            ) : (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-muted p-4 rounded-md">
                    <h3 className="text-sm font-medium mb-1">Total Budget</h3>
                    <p className="text-xl sm:text-2xl font-bold">{formatCurrency(summaryData?.total?.budget || 0)}</p>
                  </div>
                  <div className="bg-muted p-4 rounded-md">
                    <h3 className="text-sm font-medium mb-1">Total Pengeluaran</h3>
                    <p className="text-xl sm:text-2xl font-bold">{formatCurrency(summaryData?.total?.spent || 0)}</p>
                  </div>
                </div>
                <div className="bg-muted p-4 rounded-md">
                  <h3 className="text-sm font-medium mb-1">Sisa Budget</h3>
                  <p className={`text-xl sm:text-2xl font-bold ${(summaryData?.total?.remaining || 0) < 0 ? 'text-red-500' : 'text-green-500'}`}>
                    {formatCurrency(summaryData?.total?.remaining || 0)}
                  </p>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="bar" className="w-full">
        <TabsList className="mb-4 w-full justify-start overflow-auto">
          <TabsTrigger value="bar">Grafik Batang</TabsTrigger>
          <TabsTrigger value="pie">Grafik Lingkaran</TabsTrigger>
        </TabsList>
        <TabsContent value="bar" className="space-y-4">
          <Card>
            <CardHeader className="px-4 sm:px-6">
              <CardTitle className="text-lg sm:text-xl">Perbandingan Budget dan Pengeluaran</CardTitle>
              <CardDescription>Berdasarkan kategori pengeluaran</CardDescription>
            </CardHeader>
            <CardContent className="px-4 sm:px-6">
              <div className="h-[300px] sm:h-[400px]">
                {isLoading ? (
                  <p>Memuat data...</p>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={generateChartData()}
                      margin={{ top: 20, right: 10, left: 0, bottom: 60 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" angle={-45} textAnchor="end" tick={{ fontSize: 10 }} height={60} />
                      <YAxis tickFormatter={(value) => `Rp${value / 1000}k`} />
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      <Legend />
                      <Bar dataKey="budget" name="Budget" fill="#8884d8" />
                      <Bar dataKey="spent" name="Pengeluaran" fill="#82ca9d" />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="pie" className="space-y-4">
          <Card>
            <CardHeader className="px-4 sm:px-6">
              <CardTitle className="text-lg sm:text-xl">Distribusi Pengeluaran</CardTitle>
              <CardDescription>Berdasarkan kategori pengeluaran</CardDescription>
            </CardHeader>
            <CardContent className="px-4 sm:px-6">
              <div className="h-[300px] sm:h-[400px]">
                {isLoading ? (
                  <p>Memuat data...</p>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={generatePieData()}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={120}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {generatePieData().map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}