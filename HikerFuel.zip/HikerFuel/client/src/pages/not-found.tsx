import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, CircleDollarSign, Home } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-[80vh] w-full flex items-center justify-center">
      <Card className="w-full max-w-md mx-4 border-2">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center justify-center text-center mb-6">
            <AlertCircle className="h-16 w-16 text-destructive mb-4" />
            <h1 className="text-3xl font-bold">404</h1>
            <h2 className="text-xl font-semibold mt-2">Halaman Tidak Ditemukan</h2>
            <p className="mt-4 text-muted-foreground">
              Maaf, halaman yang Anda cari tidak tersedia.
            </p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-center gap-4">
          <Button asChild variant="outline">
            <Link href="/">
              <Home className="mr-2 h-4 w-4" />
              Kembali ke Beranda
            </Link>
          </Button>
          <Button asChild>
            <Link href="/budgets">
              <CircleDollarSign className="mr-2 h-4 w-4" />
              Lihat Budget
            </Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
