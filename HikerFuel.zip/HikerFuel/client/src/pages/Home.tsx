import { useCallback } from "react";
import { useLocation } from "wouter";
import { useBudget } from "@/hooks/useBudget";
import { Button } from "@/components/ui/button";
import { 
  ArrowDownCircle, 
  BarChart3, 
  CreditCard,
  CircleDollarSign,
  ReceiptText,
  Wallet,
  PieChart,
  TrendingUp,
  CalendarRange
} from "lucide-react";
import fintrackLogo from "../assets/fintrack-logo.png";

const Home = () => {
  const [, navigate] = useLocation();
  
  const handleBudgetManagement = useCallback(() => {
    navigate("/budgets");
  }, [navigate]);

  const handleExpenseTracking = useCallback(() => {
    navigate("/expenses");
  }, [navigate]);

  const handleBankConnections = useCallback(() => {
    navigate("/bank-accounts");
  }, [navigate]);

  const handleViewReports = useCallback(() => {
    navigate("/report");
  }, [navigate]);

  return (
    <main className="container mx-auto px-4 py-6 mb-20">
      {/* Splash screen appears first, then this page */}
      
      {/* Header with Beta Badge and Logo */}
      <div className="flex flex-col items-center text-center mb-10">
        <div className="bg-green-500 text-white text-sm font-medium py-1 px-3 rounded-full mb-4">
          Beta
        </div>
        <div className="mb-4">
          <img src={fintrackLogo} alt="FinTrack Logo" className="h-16" />
        </div>
        <p className="text-muted-foreground">
          Aplikasi manajemen keuangan yang membantu Anda melacak dan mengontrol pengeluaran.
        </p>
      </div>

      {/* Feature List - Enhanced with more detailed icons */}
      <div className="space-y-6 mb-10">
        <div className="flex items-center gap-4">
          <div className="bg-green-50 p-3 rounded-full w-12 h-12 flex items-center justify-center">
            <ReceiptText className="h-6 w-6 text-green-500" />
          </div>
          <div>
            <h2 className="font-medium">Lacak Pengeluaran</h2>
            <p className="text-sm text-muted-foreground">
              Catat semua pengeluaran harian Anda dengan mudah dan cepat.
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="bg-green-50 p-3 rounded-full w-12 h-12 flex items-center justify-center">
            <Wallet className="h-6 w-6 text-green-500" />
          </div>
          <div>
            <h2 className="font-medium">Atur Budget</h2>
            <p className="text-sm text-muted-foreground">
              Buat dan kelola budget untuk berbagai kategori pengeluaran.
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="bg-green-50 p-3 rounded-full w-12 h-12 flex items-center justify-center">
            <CreditCard className="h-6 w-6 text-green-500" />
          </div>
          <div>
            <h2 className="font-medium">Akses Bank</h2>
            <p className="text-sm text-muted-foreground">
              Koneksikan ke rekening bank untuk melihat saldo secara real-time.
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="bg-green-50 p-3 rounded-full w-12 h-12 flex items-center justify-center">
            <PieChart className="h-6 w-6 text-green-500" />
          </div>
          <div>
            <h2 className="font-medium">Laporan Keuangan</h2>
            <p className="text-sm text-muted-foreground">
              Dapatkan laporan visual tentang pola pengeluaran Anda.
            </p>
          </div>
        </div>
      </div>
      
      {/* Separator */}
      <div className="border-t mb-8"></div>
      
      {/* CTA Button */}
      <div className="flex justify-center">
        <Button 
          onClick={handleExpenseTracking}
          size="lg"
          className="w-full bg-green-500 hover:bg-green-600"
        >
          Buka Aplikasi
        </Button>
      </div>
      
      {/* Loading text */}
      <div className="text-center text-sm text-muted-foreground mt-8">
        <p>Tunggu sebentar sementara server sedang dimuat...</p>
      </div>
    </main>
  );
};

export default Home;
