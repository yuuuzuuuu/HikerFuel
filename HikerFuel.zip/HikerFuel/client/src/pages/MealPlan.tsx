import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import TripConfig from "@/components/TripConfig";
import MealSelection from "@/components/MealSelection";
import NutritionSummary from "@/components/NutritionSummary";
import ShoppingList from "@/components/ShoppingList";
import MealDetailModal from "@/components/MealDetailModal";
import { useMealPlan } from "@/hooks/useMealPlan";
import { Recipe, MealPlan as MealPlanType } from "@/types";

const MealPlan = () => {
  const params = useParams();
  const { id } = params;
  
  const [showMealDetail, setShowMealDetail] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  
  const { mealPlan, updateMealPlan, generateMealPlan } = useMealPlan();
  
  // If we have an ID, fetch the meal plan
  const { data: fetchedMealPlan, isLoading } = useQuery<MealPlanType>({
    queryKey: [id ? `/api/meal-plans/${id}` : null],
    enabled: !!id,
  });
  
  useEffect(() => {
    if (fetchedMealPlan && !isLoading) {
      updateMealPlan(fetchedMealPlan);
    }
  }, [fetchedMealPlan, isLoading, updateMealPlan]);
  
  const handleShowMealDetail = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    setShowMealDetail(true);
  };
  
  const handleCloseMealDetail = () => {
    setShowMealDetail(false);
  };

  const [currentSection, setCurrentSection] = useState<'config' | 'meals' | 'nutrition' | 'shopping'>('config');
  
  const renderCurrentSection = () => {
    switch (currentSection) {
      case 'config':
        return <TripConfig onNext={() => setCurrentSection('meals')} />;
      case 'meals':
        return <MealSelection onShowMealDetail={handleShowMealDetail} onNext={() => setCurrentSection('nutrition')} />;
      case 'nutrition':
        return <NutritionSummary onNext={() => setCurrentSection('shopping')} />;
      case 'shopping':
        return <ShoppingList />;
      default:
        return <TripConfig onNext={() => setCurrentSection('meals')} />;
    }
  };

  return (
    <main className="container mx-auto px-4 py-8 mb-20">
      {/* Navigation Tabs */}
      <div className="mb-6 overflow-x-auto">
        <div className="flex space-x-2 min-w-max">
          <button 
            className={`px-6 py-2 rounded-lg ${currentSection === 'config' ? 'bg-[#2D6A4F] text-white' : 'bg-[#E9ECEF] text-[#495057]'} font-medium`}
            onClick={() => setCurrentSection('config')}
          >
            Trip Details
          </button>
          <button 
            className={`px-6 py-2 rounded-lg ${currentSection === 'meals' ? 'bg-[#2D6A4F] text-white' : 'bg-[#E9ECEF] text-[#495057]'} font-medium`}
            onClick={() => setCurrentSection('meals')}
          >
            Meal Selection
          </button>
          <button 
            className={`px-6 py-2 rounded-lg ${currentSection === 'nutrition' ? 'bg-[#2D6A4F] text-white' : 'bg-[#E9ECEF] text-[#495057]'} font-medium`}
            onClick={() => setCurrentSection('nutrition')}
          >
            Nutrition
          </button>
          <button 
            className={`px-6 py-2 rounded-lg ${currentSection === 'shopping' ? 'bg-[#2D6A4F] text-white' : 'bg-[#E9ECEF] text-[#495057]'} font-medium`}
            onClick={() => setCurrentSection('shopping')}
          >
            Shopping List
          </button>
        </div>
      </div>
      
      {/* Current Section Content */}
      {renderCurrentSection()}
      
      {/* Action Buttons */}
      <div className="flex justify-end space-x-4 mb-8">
        <button className="bg-white border border-[#CED4DA] text-[#495057] px-5 py-2.5 rounded-lg hover:text-[#2D6A4F] hover:border-[#2D6A4F] transition-all flex items-center">
          <i className="ri-save-line mr-2"></i>
          Save Plan
        </button>
        <button className="bg-[#2D6A4F] hover:bg-[#1B4332] text-white px-5 py-2.5 rounded-lg transition-all flex items-center">
          <i className="ri-share-line mr-2"></i>
          Share Plan
        </button>
      </div>
      
      {/* Meal Detail Modal */}
      {selectedRecipe && (
        <MealDetailModal 
          show={showMealDetail} 
          onClose={handleCloseMealDetail} 
          recipe={selectedRecipe} 
        />
      )}
    </main>
  );
};

export default MealPlan;
