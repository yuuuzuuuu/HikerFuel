import { useState } from "react";
import { useLocation } from "wouter";
import { useBudget } from "@/hooks/useBudget";
import { Expense, ExpenseCategory, PaymentMethod } from "@/types";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { 
  ArrowLeft, 
  Plus, 
  Wallet,
  Calendar,
  Edit,
  Trash,
  CreditCard,
  BanknoteIcon,
} from "lucide-react";
import { format } from "date-fns";

export default function Expenses() {
  const [, navigate] = useLocation();
  const { 
    expenses, 
    isLoadingExpenses, 
    formatCurrency,
    createExpense,
    isCreatingExpense,
    updateExpense,
    isUpdatingExpense,
    deleteExpense,
    isDeletingExpense,
  } = useBudget();

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [currentExpense, setCurrentExpense] = useState<Expense | null>(null);
  
  const [newExpense, setNewExpense] = useState<Partial<Expense>>({
    amount: 0,
    description: "",
    category: "lainnya",
    date: new Date(),
    paymentMethod: "tunai",
    notes: ""
  });

  const handleAddExpense = () => {
    createExpense(newExpense);
    setIsAddDialogOpen(false);
    setNewExpense({
      amount: 0,
      description: "",
      category: "lainnya",
      date: new Date(),
      paymentMethod: "tunai",
      notes: ""
    });
  };

  const handleEditExpense = () => {
    if (currentExpense && currentExpense.id) {
      // Omit id to avoid sending it in the update
      const { id, ...expenseUpdate } = currentExpense;
      updateExpense({ id, expense: expenseUpdate });
      setIsEditDialogOpen(false);
      setCurrentExpense(null);
    }
  };

  const handleDeleteExpense = () => {
    if (currentExpense && currentExpense.id) {
      deleteExpense(currentExpense.id);
      setIsDeleteDialogOpen(false);
      setCurrentExpense(null);
    }
  };

  // Helper for category display
  const getCategoryLabel = (category: ExpenseCategory) => {
    switch (category) {
      case "makanan": return "Makanan";
      case "transportasi": return "Transportasi";
      case "belanja": return "Belanja";
      case "hiburan": return "Hiburan";
      case "kesehatan": return "Kesehatan";
      case "pendidikan": return "Pendidikan";
      case "tagihan": return "Tagihan";
      case "lainnya": return "Lainnya";
      default: return category;
    }
  };
  
  // Helper for payment method display
  const getPaymentMethodLabel = (method: PaymentMethod) => {
    switch (method) {
      case "tunai": return "Tunai";
      case "kartu-kredit": return "Kartu Kredit";
      case "kartu-debit": return "Kartu Debit";
      case "e-wallet": return "E-Wallet";
      case "transfer-bank": return "Transfer Bank";
      case "lainnya": return "Lainnya";
      default: return method;
    }
  };

  // Format date to human readable format
  const formatDate = (date: Date) => {
    return format(new Date(date), "dd MMMM yyyy");
  };

  return (
    <main className="container mx-auto px-4 py-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            className="h-9 w-9 p-0"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl sm:text-2xl font-bold">Catat Pengeluaran</h1>
        </div>
        <Button 
          onClick={() => setIsAddDialogOpen(true)}
          className="flex items-center gap-2 w-full sm:w-auto"
        >
          <Plus className="h-4 w-4" />
          Tambah Pengeluaran
        </Button>
      </div>

      {/* Expense Cards */}
      <div className="space-y-4 mb-8">
        {isLoadingExpenses ? (
          // Loading state
          Array(3).fill(0).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between">
                  <div>
                    <Skeleton className="h-5 w-48 mb-2" />
                    <Skeleton className="h-8 w-24" />
                  </div>
                  <div>
                    <Skeleton className="h-8 w-20" />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : expenses.length === 0 ? (
          // Empty state
          <div className="flex flex-col items-center justify-center py-12 border border-dashed rounded-lg">
            <Wallet className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Belum ada pengeluaran</h3>
            <p className="text-muted-foreground mb-4 text-center max-w-md">
              Catat pengeluaran baru untuk membantu Anda melacak dan mengontrol keuangan.
            </p>
            <Button 
              onClick={() => setIsAddDialogOpen(true)}
              className="flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              Tambah Pengeluaran
            </Button>
          </div>
        ) : (
          // Content - sort by date (newest first)
          [...expenses]
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
            .map(expense => (
              <Card key={expense.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl">{expense.description}</CardTitle>
                      <div className="text-2xl font-bold text-destructive">{formatCurrency(expense.amount)}</div>
                    </div>
                    <div className="flex gap-1">
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => {
                          setCurrentExpense(expense);
                          setIsEditDialogOpen(true);
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => {
                          setCurrentExpense(expense);
                          setIsDeleteDialogOpen(true);
                        }}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 flex-shrink-0" />
                      <span>{formatDate(expense.date)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <BanknoteIcon className="h-4 w-4 flex-shrink-0" />
                      <span className="truncate">Kategori: {getCategoryLabel(expense.category as ExpenseCategory)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CreditCard className="h-4 w-4 flex-shrink-0" />
                      <span className="truncate">{getPaymentMethodLabel(expense.paymentMethod as PaymentMethod)}</span>
                    </div>
                  </div>
                  {expense.notes && (
                    <div className="mt-2 text-sm">
                      <span className="font-medium">Catatan:</span> {expense.notes}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
        )}
      </div>

      {/* Add Expense Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-[95%] sm:max-w-[425px] p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-lg sm:text-xl">Tambah Pengeluaran</DialogTitle>
            <DialogDescription>
              Catat pengeluaran baru untuk melacak keuangan Anda.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
              <Label htmlFor="description" className="sm:text-right">
                Deskripsi
              </Label>
              <Input
                id="description"
                placeholder="Contoh: Makan Siang"
                className="sm:col-span-3"
                value={newExpense.description}
                onChange={(e) => setNewExpense({ ...newExpense, description: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
              <Label htmlFor="amount" className="sm:text-right">
                Jumlah
              </Label>
              <Input
                id="amount"
                type="number"
                placeholder="0"
                className="sm:col-span-3"
                value={newExpense.amount || ''}
                onChange={(e) => setNewExpense({ ...newExpense, amount: parseInt(e.target.value) || 0 })}
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
              <Label htmlFor="category" className="sm:text-right">
                Kategori
              </Label>
              <Select 
                value={newExpense.category as string}
                onValueChange={(value) => setNewExpense({ ...newExpense, category: value as ExpenseCategory })}
              >
                <SelectTrigger className="sm:col-span-3">
                  <SelectValue placeholder="Pilih kategori" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="makanan">Makanan</SelectItem>
                  <SelectItem value="transportasi">Transportasi</SelectItem>
                  <SelectItem value="belanja">Belanja</SelectItem>
                  <SelectItem value="hiburan">Hiburan</SelectItem>
                  <SelectItem value="kesehatan">Kesehatan</SelectItem>
                  <SelectItem value="pendidikan">Pendidikan</SelectItem>
                  <SelectItem value="tagihan">Tagihan</SelectItem>
                  <SelectItem value="lainnya">Lainnya</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
              <Label htmlFor="paymentMethod" className="sm:text-right">
                Metode
              </Label>
              <Select 
                value={newExpense.paymentMethod as string}
                onValueChange={(value) => setNewExpense({ ...newExpense, paymentMethod: value as PaymentMethod })}
              >
                <SelectTrigger className="sm:col-span-3">
                  <SelectValue placeholder="Pilih metode pembayaran" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tunai">Tunai</SelectItem>
                  <SelectItem value="kartu-kredit">Kartu Kredit</SelectItem>
                  <SelectItem value="kartu-debit">Kartu Debit</SelectItem>
                  <SelectItem value="e-wallet">E-Wallet</SelectItem>
                  <SelectItem value="transfer-bank">Transfer Bank</SelectItem>
                  <SelectItem value="lainnya">Lainnya</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
              <Label htmlFor="date" className="sm:text-right">
                Tanggal
              </Label>
              <Input
                id="date"
                type="date"
                className="sm:col-span-3"
                value={newExpense.date ? format(new Date(newExpense.date), "yyyy-MM-dd") : ''}
                onChange={(e) => setNewExpense({ ...newExpense, date: new Date(e.target.value) })}
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
              <Label htmlFor="notes" className="sm:text-right">
                Catatan
              </Label>
              <Textarea
                id="notes"
                placeholder="Opsional"
                className="sm:col-span-3"
                value={newExpense.notes || ''}
                onChange={(e) => setNewExpense({ ...newExpense, notes: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button 
              variant="outline" 
              onClick={() => setIsAddDialogOpen(false)}
              className="w-full sm:w-auto"
            >
              Batal
            </Button>
            <Button 
              onClick={handleAddExpense}
              disabled={isCreatingExpense || !newExpense.description || !newExpense.amount}
              className="w-full sm:w-auto"
            >
              {isCreatingExpense ? "Menyimpan..." : "Simpan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Expense Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-[95%] sm:max-w-[425px] p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-lg sm:text-xl">Edit Pengeluaran</DialogTitle>
            <DialogDescription>
              Ubah detail pengeluaran Anda.
            </DialogDescription>
          </DialogHeader>
          {currentExpense && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
                <Label htmlFor="edit-description" className="sm:text-right">
                  Deskripsi
                </Label>
                <Input
                  id="edit-description"
                  className="sm:col-span-3"
                  value={currentExpense.description}
                  onChange={(e) => setCurrentExpense({ ...currentExpense, description: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
                <Label htmlFor="edit-amount" className="sm:text-right">
                  Jumlah
                </Label>
                <Input
                  id="edit-amount"
                  type="number"
                  className="sm:col-span-3"
                  value={currentExpense.amount}
                  onChange={(e) => setCurrentExpense({ ...currentExpense, amount: parseInt(e.target.value) || 0 })}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
                <Label htmlFor="edit-category" className="sm:text-right">
                  Kategori
                </Label>
                <Select 
                  value={currentExpense.category as string}
                  onValueChange={(value) => setCurrentExpense({ ...currentExpense, category: value as ExpenseCategory })}
                >
                  <SelectTrigger className="sm:col-span-3">
                    <SelectValue placeholder="Pilih kategori" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="makanan">Makanan</SelectItem>
                    <SelectItem value="transportasi">Transportasi</SelectItem>
                    <SelectItem value="belanja">Belanja</SelectItem>
                    <SelectItem value="hiburan">Hiburan</SelectItem>
                    <SelectItem value="kesehatan">Kesehatan</SelectItem>
                    <SelectItem value="pendidikan">Pendidikan</SelectItem>
                    <SelectItem value="tagihan">Tagihan</SelectItem>
                    <SelectItem value="lainnya">Lainnya</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
                <Label htmlFor="edit-paymentMethod" className="sm:text-right">
                  Metode
                </Label>
                <Select 
                  value={currentExpense.paymentMethod as string}
                  onValueChange={(value) => setCurrentExpense({ ...currentExpense, paymentMethod: value as PaymentMethod })}
                >
                  <SelectTrigger className="sm:col-span-3">
                    <SelectValue placeholder="Pilih metode pembayaran" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tunai">Tunai</SelectItem>
                    <SelectItem value="kartu-kredit">Kartu Kredit</SelectItem>
                    <SelectItem value="kartu-debit">Kartu Debit</SelectItem>
                    <SelectItem value="e-wallet">E-Wallet</SelectItem>
                    <SelectItem value="transfer-bank">Transfer Bank</SelectItem>
                    <SelectItem value="lainnya">Lainnya</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
                <Label htmlFor="edit-date" className="sm:text-right">
                  Tanggal
                </Label>
                <Input
                  id="edit-date"
                  type="date"
                  className="sm:col-span-3"
                  value={format(new Date(currentExpense.date), "yyyy-MM-dd")}
                  onChange={(e) => setCurrentExpense({ ...currentExpense, date: new Date(e.target.value) })}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-start sm:items-center gap-2 sm:gap-4">
                <Label htmlFor="edit-notes" className="sm:text-right">
                  Catatan
                </Label>
                <Textarea
                  id="edit-notes"
                  className="sm:col-span-3"
                  value={currentExpense.notes || ''}
                  onChange={(e) => setCurrentExpense({ ...currentExpense, notes: e.target.value })}
                />
              </div>
            </div>
          )}
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button 
              variant="outline" 
              onClick={() => setIsEditDialogOpen(false)}
              className="w-full sm:w-auto"
            >
              Batal
            </Button>
            <Button 
              onClick={handleEditExpense}
              disabled={isUpdatingExpense || !currentExpense?.description || !currentExpense?.amount}
              className="w-full sm:w-auto"
            >
              {isUpdatingExpense ? "Memperbarui..." : "Perbarui"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Expense Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="max-w-[95%] sm:max-w-[425px] p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-lg sm:text-xl">Hapus Pengeluaran</DialogTitle>
            <DialogDescription>
              Apakah Anda yakin ingin menghapus pengeluaran ini? Tindakan ini tidak dapat dibatalkan.
            </DialogDescription>
          </DialogHeader>
          {currentExpense && (
            <div className="py-4">
              <p className="font-medium">{currentExpense.description}</p>
              <p className="text-destructive">{formatCurrency(currentExpense.amount)}</p>
              <p className="text-sm text-muted-foreground">{formatDate(currentExpense.date)}</p>
            </div>
          )}
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button 
              variant="outline" 
              onClick={() => setIsDeleteDialogOpen(false)}
              className="w-full sm:w-auto"
            >
              Batal
            </Button>
            <Button 
              variant="destructive"
              onClick={handleDeleteExpense}
              disabled={isDeletingExpense}
              className="w-full sm:w-auto"
            >
              {isDeletingExpense ? "Menghapus..." : "Hapus"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </main>
  );
}