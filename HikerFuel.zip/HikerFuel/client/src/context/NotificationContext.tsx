import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Notification } from "../components/NotificationCenter";

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  addNotification: (notification: Omit<Notification, "id" | "date" | "read">) => void;
  markAsRead: (id: number) => void;
  markAllAsRead: () => void;
  removeNotification: (id: number) => void;
  clearAllNotifications: () => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

// Mock data awal untuk notifikasi
const initialNotifications: Notification[] = [
  {
    id: 1,
    title: "Batas Anggaran Terlampaui",
    message: "Anggaran makanan bulan ini telah melampaui 80%",
    type: "warning",
    read: false,
    date: new Date(Date.now() - 1000 * 60 * 30), // 30 menit yang lalu
    link: "/budgets"
  },
  {
    id: 2,
    title: "Pengeluaran Baru",
    message: "Transaksi di BCA sebesar Rp 150.000",
    type: "info",
    read: false,
    date: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 jam yang lalu
    link: "/expenses"
  },
  {
    id: 3,
    title: "Anggaran Berhasil Dibuat",
    message: "Anggaran transportasi bulanan berhasil dibuat",
    type: "success",
    read: true,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 hari yang lalu
    link: "/budgets"
  },
];

export const NotificationProvider = ({ children }: { children: ReactNode }) => {
  const [notifications, setNotifications] = useState<Notification[]>(initialNotifications);
  const [unreadCount, setUnreadCount] = useState<number>(0);

  // Menghitung jumlah notifikasi yang belum dibaca
  useEffect(() => {
    const count = notifications.filter(notification => !notification.read).length;
    setUnreadCount(count);
  }, [notifications]);

  // Fungsi untuk menambahkan notifikasi baru
  const addNotification = (notification: Omit<Notification, "id" | "date" | "read">) => {
    const newNotification: Notification = {
      ...notification,
      id: Date.now(), // Menggunakan timestamp sebagai ID sederhana
      date: new Date(),
      read: false,
    };

    setNotifications(prevNotifications => [newNotification, ...prevNotifications]);
  };

  // Fungsi untuk menandai notifikasi sebagai sudah dibaca
  const markAsRead = (id: number) => {
    setNotifications(prevNotifications => 
      prevNotifications.map(notification => 
        notification.id === id 
          ? { ...notification, read: true } 
          : notification
      )
    );
  };

  // Fungsi untuk menandai semua notifikasi sebagai sudah dibaca
  const markAllAsRead = () => {
    setNotifications(prevNotifications => 
      prevNotifications.map(notification => ({ ...notification, read: true }))
    );
  };

  // Fungsi untuk menghapus notifikasi
  const removeNotification = (id: number) => {
    setNotifications(prevNotifications => 
      prevNotifications.filter(notification => notification.id !== id)
    );
  };

  // Fungsi untuk menghapus semua notifikasi
  const clearAllNotifications = () => {
    setNotifications([]);
  };

  return (
    <NotificationContext.Provider 
      value={{ 
        notifications, 
        unreadCount,
        addNotification, 
        markAsRead, 
        markAllAsRead,
        removeNotification,
        clearAllNotifications
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

// Hook untuk mengakses context
export const useNotifications = () => {
  const context = useContext(NotificationContext);
  
  if (context === undefined) {
    throw new Error("useNotifications harus digunakan dalam NotificationProvider");
  }
  
  return context;
};