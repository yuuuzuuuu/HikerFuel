import { Recipe, MealType } from "@/types";

// This file exists to provide utility functions for meal-related calculations
// and data processing for the frontend. It does not contain any mock data.

/**
 * Calculate the total calories required for a day based on activity level and base calorie needs
 */
export function calculateRequiredCalories(
  activityLevel: string,
  baseCalories: number = 2000
): number {
  switch (activityLevel) {
    case "low":
      return baseCalories + 500; // Low intensity hiking
    case "moderate":
      return baseCalories + 800; // Moderate hiking (5-10 miles)
    case "high":
      return baseCalories + 1200; // High intensity hiking (10-15 miles)
    case "extreme":
      return baseCalories + 1600; // Extreme hiking (15+ miles)
    default:
      return baseCalories + 800; // Default to moderate
  }
}

/**
 * Calculate the protein in grams based on calorie needs and protein percentage
 */
export function calculateProteinGrams(
  calories: number,
  proteinPercentage: number
): number {
  // Protein has 4 calories per gram
  return Math.round((calories * proteinPercentage) / 100 / 4);
}

/**
 * Calculate the carbs in grams based on calorie needs and carb percentage
 */
export function calculateCarbGrams(
  calories: number,
  carbPercentage: number
): number {
  // Carbs have 4 calories per gram
  return Math.round((calories * carbPercentage) / 100 / 4);
}

/**
 * Calculate the fat in grams based on calorie needs and fat percentage
 */
export function calculateFatGrams(
  calories: number,
  fatPercentage: number
): number {
  // Fat has 9 calories per gram
  return Math.round((calories * fatPercentage) / 100 / 9);
}

/**
 * Calculate the distribution of calories across meal types
 */
export function calculateMealDistribution(
  totalCalories: number
): Record<MealType, number> {
  return {
    breakfast: Math.round(totalCalories * 0.25), // 25% of daily calories
    lunch: Math.round(totalCalories * 0.3), // 30% of daily calories
    dinner: Math.round(totalCalories * 0.35), // 35% of daily calories
    snack: Math.round(totalCalories * 0.1), // 10% of daily calories
  };
}

/**
 * Filter recipes based on dietary preferences
 */
export function filterRecipesByDietaryPreferences(
  recipes: Recipe[],
  dietaryPreferences: string[]
): Recipe[] {
  if (!dietaryPreferences.length) {
    return recipes;
  }

  return recipes.filter((recipe) => {
    const recipeTags = recipe.dietaryTags as string[];
    return dietaryPreferences.every((pref) => recipeTags.includes(pref));
  });
}

/**
 * Get meal recommendations based on dietary preferences, calorie needs, and meal type
 */
export function getMealRecommendations(
  recipes: Recipe[],
  dietaryPreferences: string[],
  calorieTarget: number,
  mealType: MealType
): Recipe[] {
  // Filter by dietary preferences and meal type
  const filteredRecipes = recipes.filter(
    (recipe) =>
      recipe.mealType === mealType &&
      (dietaryPreferences.length === 0 ||
        dietaryPreferences.every((pref) =>
          (recipe.dietaryTags as string[]).includes(pref)
        ))
  );

  // Sort by how close the calories are to the target
  return [...filteredRecipes].sort((a, b) => {
    const aDiff = Math.abs(a.calories - calorieTarget);
    const bDiff = Math.abs(b.calories - calorieTarget);
    return aDiff - bDiff;
  });
}

/**
 * Calculate how many servings of an ingredient are needed based on people and days
 */
export function calculateIngredientQuantity(
  ingredient: string,
  people: number,
  days: number
): string {
  const lowerIngredient = ingredient.toLowerCase();
  
  // Packets/bars
  if (lowerIngredient.includes('packet') || lowerIngredient.includes('bar')) {
    return `${people * days} ${lowerIngredient.includes('packet') ? 'packets' : 'bars'}`;
  }
  
  // Canned items
  if (lowerIngredient.includes('can')) {
    return `${Math.ceil(people * days / 2)} cans`;
  }
  
  // Weight-based items
  if (lowerIngredient.includes('oatmeal') || lowerIngredient.includes('quinoa')) {
    return `${people * days * 50}g`;
  }
  
  if (lowerIngredient.includes('jerky') || lowerIngredient.includes('dried')) {
    return `${people * days * 30}g`;
  }
  
  // Count-based items
  if (lowerIngredient.includes('wrap')) {
    return `${people * days} wraps`;
  }
  
  // Packs
  if (lowerIngredient.includes('vegetable') || lowerIngredient.includes('bean')) {
    return `${Math.ceil(people * days / 3)} packs`;
  }
  
  // Default
  return `${people * days} servings`;
}
