import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Info } from "lucide-react";

const BANKS = [
  { id: "bca", name: "Bank Central Asia (BCA)" },
  { id: "mandiri", name: "Bank Mandiri" },
  { id: "bni", name: "Bank Negara Indonesia (BNI)" },
  { id: "bri", name: "Bank Rakyat Indonesia (BRI)" },
  { id: "cimb", name: "CIMB Niaga" },
  { id: "danamon", name: "Bank Danamon" },
  { id: "permata", name: "Bank Permata" },
];

interface BankConnectionProps {
  onConnect?: () => void;
  onCancel?: () => void;
}

const BankConnection = ({ onConnect, onCancel }: BankConnectionProps) => {
  const [step, setStep] = useState<"select" | "credentials" | "success" | "error">("select");
  const [selectedBank, setSelectedBank] = useState<string>("");
  const [username, setUsername] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);

  const handleSelectBank = (value: string) => {
    setSelectedBank(value);
  };

  const handleNext = () => {
    if (step === "select" && selectedBank) {
      setStep("credentials");
    } else if (step === "credentials") {
      // Simulasi koneksi ke bank
      setLoading(true);
      setTimeout(() => {
        if (username && password) {
          setStep("success");
        } else {
          setStep("error");
        }
        setLoading(false);
      }, 2000);
    } else if (step === "success" && onConnect) {
      onConnect();
    } else if (step === "error") {
      setStep("credentials");
    }
  };

  const handleCancel = () => {
    if (onCancel) {
      onCancel();
    }
  };

  const getSelectedBankName = () => {
    const bank = BANKS.find(b => b.id === selectedBank);
    return bank ? bank.name : "";
  };

  return (
    <Card className="max-w-lg mx-auto">
      <CardHeader>
        <CardTitle>Hubungkan Rekening Bank</CardTitle>
        <CardDescription>
          Hubungkan rekening bank Anda untuk memantau saldo dan transaksi secara otomatis
        </CardDescription>
      </CardHeader>
      <CardContent>
        {step === "select" && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="bank">Pilih Bank</Label>
              <Select onValueChange={handleSelectBank} value={selectedBank}>
                <SelectTrigger id="bank">
                  <SelectValue placeholder="Pilih bank Anda" />
                </SelectTrigger>
                <SelectContent>
                  {BANKS.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Alert className="bg-blue-50 text-blue-800 border-blue-200">
              <Info className="h-4 w-4 text-blue-600" />
              <AlertTitle>Informasi</AlertTitle>
              <AlertDescription>
                Kami menggunakan koneksi terenkripsi dan aman. Data login Anda tidak disimpan.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {step === "credentials" && (
          <div className="space-y-4">
            <div className="text-sm font-medium mb-4 text-foreground">
              Masukkan kredensial {getSelectedBankName()} Anda
            </div>

            <div className="space-y-2">
              <Label htmlFor="username">User ID / Username</Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Masukkan user ID internet banking"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Masukkan password internet banking"
              />
            </div>

            <Alert className="bg-amber-50 text-amber-800 border-amber-200">
              <Info className="h-4 w-4 text-amber-600" />
              <AlertTitle>Perhatian</AlertTitle>
              <AlertDescription>
                FinTrack hanya mengakses data transaksi dan tidak dapat melakukan transaksi atas nama Anda.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {step === "success" && (
          <div className="space-y-4 text-center py-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-8 w-8 text-green-600"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>
            <div className="text-xl font-semibold">Berhasil Terhubung!</div>
            <div className="text-muted-foreground">
              Rekening {getSelectedBankName()} Anda telah berhasil terhubung dengan FinTrack. Anda sekarang dapat melihat saldo dan transaksi secara otomatis.
            </div>
          </div>
        )}

        {step === "error" && (
          <div className="space-y-4 text-center py-4">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-8 w-8 text-red-600"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </div>
            <div className="text-xl font-semibold">Koneksi Gagal</div>
            <div className="text-muted-foreground">
              Gagal menghubungkan ke rekening {getSelectedBankName()} Anda. Pastikan kredensial yang Anda masukkan benar dan coba lagi.
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={handleCancel}>
          {step === "success" ? "Tutup" : "Batal"}
        </Button>
        <Button 
          onClick={handleNext} 
          disabled={loading || (step === "select" && !selectedBank) || (step === "credentials" && (!username || !password))}
        >
          {loading ? "Menghubungkan..." : 
            step === "select" ? "Lanjutkan" : 
            step === "credentials" ? "Hubungkan" : 
            step === "success" ? "Selesai" : 
            "Coba Lagi"}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default BankConnection;