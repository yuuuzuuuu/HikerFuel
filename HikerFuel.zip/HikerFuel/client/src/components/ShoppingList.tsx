import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useMealPlan } from "@/hooks/useMealPlan";
import { useToast } from "@/hooks/use-toast";

interface ShoppingListItem {
  name: string;
  quantity: string;
  checked: boolean;
}

interface ShoppingListData {
  grainsAndStarches: string[];
  proteins: string[];
  fruitsAndVegetables: string[];
  condimentsAndOther: string[];
}

const ShoppingList = () => {
  const { mealPlan } = useMealPlan();
  const { toast } = useToast();
  const [showQuantities, setShowQuantities] = useState(true);
  
  // State for shopping list items
  const [shoppingList, setShoppingList] = useState<{
    grainsAndStarches: ShoppingListItem[];
    proteins: ShoppingListItem[];
    fruitsAndVegetables: ShoppingListItem[];
    condimentsAndOther: ShoppingListItem[];
  }>({
    grainsAndStarches: [],
    proteins: [],
    fruitsAndVegetables: [],
    condimentsAndOther: []
  });
  
  // Get shopping list data from API
  const { data: shopData, isLoading } = useQuery<ShoppingListData>({
    queryKey: ['/api/meal-plans/shopping-list', mealPlan.id],
    queryFn: async () => {
      if (!mealPlan.id) {
        // Return dummy data if we don't have a saved meal plan yet
        return {
          grainsAndStarches: ["Instant Oatmeal", "Gluten-free Wraps", "Quinoa"],
          proteins: ["Canned Tuna", "Beef Jerky", "Dehydrated Beans"],
          fruitsAndVegetables: ["Dried Blueberries", "Freeze-dried Vegetables", "Trail Mix"],
          condimentsAndOther: ["Salt & Pepper Packets", "Olive Oil (travel size)", "Energy Bars"]
        };
      }
      
      const response = await fetch(`/api/meal-plans/${mealPlan.id}/shopping-list`);
      if (!response.ok) {
        throw new Error('Failed to fetch shopping list');
      }
      return response.json();
    }
  });
  
  // Convert API data to shopping list with quantities
  useEffect(() => {
    if (shopData) {
      const newList = {
        grainsAndStarches: shopData.grainsAndStarches.map(item => ({
          name: item,
          quantity: generateQuantity(item, mealPlan.people, mealPlan.days),
          checked: false
        })),
        proteins: shopData.proteins.map(item => ({
          name: item,
          quantity: generateQuantity(item, mealPlan.people, mealPlan.days),
          checked: false
        })),
        fruitsAndVegetables: shopData.fruitsAndVegetables.map(item => ({
          name: item,
          quantity: generateQuantity(item, mealPlan.people, mealPlan.days),
          checked: false
        })),
        condimentsAndOther: shopData.condimentsAndOther.map(item => ({
          name: item,
          quantity: generateQuantity(item, mealPlan.people, mealPlan.days),
          checked: false
        }))
      };
      
      setShoppingList(newList);
    }
  }, [shopData, mealPlan.people, mealPlan.days]);
  
  // Helper to generate realistic quantities
  const generateQuantity = (item: string, people: number, days: number) => {
    const lowerItem = item.toLowerCase();
    
    // Packets/bars
    if (lowerItem.includes('packet') || lowerItem.includes('bar')) {
      return `${people * days} ${lowerItem.includes('packet') ? 'packets' : 'bars'}`;
    }
    
    // Canned items
    if (lowerItem.includes('can')) {
      return `${Math.ceil(people * days / 2)} cans`;
    }
    
    // Weight-based items
    if (lowerItem.includes('oatmeal') || lowerItem.includes('quinoa')) {
      return `${people * days * 50}g`;
    }
    
    if (lowerItem.includes('jerky') || lowerItem.includes('dried')) {
      return `${people * days * 30}g`;
    }
    
    // Count-based items
    if (lowerItem.includes('wrap')) {
      return `${people * days} wraps`;
    }
    
    // Packs
    if (lowerItem.includes('vegetable') || lowerItem.includes('bean')) {
      return `${Math.ceil(people * days / 3)} packs`;
    }
    
    // Default
    return `${people * days} servings`;
  };
  
  const handleToggleItem = (category: keyof typeof shoppingList, index: number) => {
    const newList = { ...shoppingList };
    newList[category][index].checked = !newList[category][index].checked;
    setShoppingList(newList);
  };
  
  const handleAddCustomItem = () => {
    // In a real app, this would show a modal to add a custom item
    toast({
      title: "Add Custom Item",
      description: "This feature would allow adding custom items to your shopping list.",
    });
  };
  
  const handleSaveShoppingList = () => {
    toast({
      title: "Shopping List Saved",
      description: "Your shopping list has been saved successfully.",
    });
  };
  
  const handlePrintShoppingList = () => {
    window.print();
  };
  
  const handleExportShoppingList = () => {
    toast({
      title: "Shopping List Exported",
      description: "Your shopping list has been exported to your downloads folder.",
    });
  };
  
  // Count total items
  const totalItems = Object.values(shoppingList).reduce(
    (sum, category) => sum + category.length, 
    0
  );
  
  if (isLoading) {
    return (
      <section className="mb-8">
        <div className="flex justify-center p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#2D6A4F]"></div>
        </div>
      </section>
    );
  }
  
  return (
    <section className="mb-8 bg-white rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.05)] p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-semibold">Shopping List</h2>
        <div className="flex space-x-3">
          <button 
            onClick={handlePrintShoppingList}
            className="bg-white border border-[#CED4DA] hover:border-[#2D6A4F] text-[#495057] hover:text-[#2D6A4F] px-4 py-2 rounded-lg transition-all flex items-center"
          >
            <i className="ri-printer-line mr-2"></i>
            Print
          </button>
          <button 
            onClick={handleExportShoppingList}
            className="bg-white border border-[#CED4DA] hover:border-[#2D6A4F] text-[#495057] hover:text-[#2D6A4F] px-4 py-2 rounded-lg transition-all flex items-center"
          >
            <i className="ri-download-line mr-2"></i>
            Export
          </button>
        </div>
      </div>
      
      <div className="mb-4 flex items-center justify-between">
        <div className="text-sm text-[#495057]">Total Items: <span className="font-medium">{totalItems}</span></div>
        <label className="inline-flex items-center cursor-pointer">
          <span className="mr-2 text-sm">Show Quantities</span>
          <div className="relative">
            <input 
              type="checkbox" 
              checked={showQuantities}
              onChange={() => setShowQuantities(!showQuantities)}
              className="sr-only peer" 
            />
            <div className="w-10 h-5 bg-[#CED4DA] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#2D6A4F]"></div>
          </div>
        </label>
      </div>
      
      {/* Shopping List Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Grains & Starches */}
        <div className="bg-[#F8FAF9] rounded-lg p-4">
          <h3 className="font-medium mb-3 flex items-center">
            <i className="ri-seedling-line text-[#2D6A4F] mr-2"></i>
            Grains & Starches
          </h3>
          <ul className="space-y-2">
            {shoppingList.grainsAndStarches.map((item, index) => (
              <li key={index} className="flex items-center justify-between">
                <div className="flex items-center">
                  <input 
                    type="checkbox" 
                    checked={item.checked}
                    onChange={() => handleToggleItem('grainsAndStarches', index)}
                    className="w-4 h-4 text-[#2D6A4F] accent-[#2D6A4F] rounded-sm mr-3" 
                  />
                  <span className={item.checked ? "line-through text-[#495057]/60" : ""}>{item.name}</span>
                </div>
                {showQuantities && <span className="text-sm text-[#495057]">{item.quantity}</span>}
              </li>
            ))}
          </ul>
        </div>
        
        {/* Proteins */}
        <div className="bg-[#F8FAF9] rounded-lg p-4">
          <h3 className="font-medium mb-3 flex items-center">
            <i className="ri-meat-line text-[#9C6644] mr-2"></i>
            Proteins
          </h3>
          <ul className="space-y-2">
            {shoppingList.proteins.map((item, index) => (
              <li key={index} className="flex items-center justify-between">
                <div className="flex items-center">
                  <input 
                    type="checkbox" 
                    checked={item.checked}
                    onChange={() => handleToggleItem('proteins', index)}
                    className="w-4 h-4 text-[#2D6A4F] accent-[#2D6A4F] rounded-sm mr-3" 
                  />
                  <span className={item.checked ? "line-through text-[#495057]/60" : ""}>{item.name}</span>
                </div>
                {showQuantities && <span className="text-sm text-[#495057]">{item.quantity}</span>}
              </li>
            ))}
          </ul>
        </div>
        
        {/* Fruits & Vegetables */}
        <div className="bg-[#F8FAF9] rounded-lg p-4">
          <h3 className="font-medium mb-3 flex items-center">
            <i className="ri-plant-line text-[#40916C] mr-2"></i>
            Fruits & Vegetables
          </h3>
          <ul className="space-y-2">
            {shoppingList.fruitsAndVegetables.map((item, index) => (
              <li key={index} className="flex items-center justify-between">
                <div className="flex items-center">
                  <input 
                    type="checkbox" 
                    checked={item.checked}
                    onChange={() => handleToggleItem('fruitsAndVegetables', index)}
                    className="w-4 h-4 text-[#2D6A4F] accent-[#2D6A4F] rounded-sm mr-3" 
                  />
                  <span className={item.checked ? "line-through text-[#495057]/60" : ""}>{item.name}</span>
                </div>
                {showQuantities && <span className="text-sm text-[#495057]">{item.quantity}</span>}
              </li>
            ))}
          </ul>
        </div>
        
        {/* Condiments & Other */}
        <div className="bg-[#F8FAF9] rounded-lg p-4">
          <h3 className="font-medium mb-3 flex items-center">
            <i className="ri-flask-line text-[#E9C46A] mr-2"></i>
            Condiments & Other
          </h3>
          <ul className="space-y-2">
            {shoppingList.condimentsAndOther.map((item, index) => (
              <li key={index} className="flex items-center justify-between">
                <div className="flex items-center">
                  <input 
                    type="checkbox" 
                    checked={item.checked}
                    onChange={() => handleToggleItem('condimentsAndOther', index)}
                    className="w-4 h-4 text-[#2D6A4F] accent-[#2D6A4F] rounded-sm mr-3" 
                  />
                  <span className={item.checked ? "line-through text-[#495057]/60" : ""}>{item.name}</span>
                </div>
                {showQuantities && <span className="text-sm text-[#495057]">{item.quantity}</span>}
              </li>
            ))}
          </ul>
        </div>
      </div>
      
      <div className="mt-6 flex justify-between">
        <button 
          onClick={handleAddCustomItem}
          className="border border-[#CED4DA] text-[#495057] px-4 py-2 rounded-lg hover:text-[#2D6A4F] hover:border-[#2D6A4F] transition-all"
        >
          Add Custom Item
        </button>
        <button 
          onClick={handleSaveShoppingList}
          className="bg-[#2D6A4F] hover:bg-[#1B4332] text-white px-5 py-2.5 rounded-lg transition-all flex items-center"
        >
          <i className="ri-save-line mr-2"></i>
          Save Shopping List
        </button>
      </div>
    </section>
  );
};

export default ShoppingList;
