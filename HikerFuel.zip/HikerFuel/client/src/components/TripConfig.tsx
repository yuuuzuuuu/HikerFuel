import { useState } from "react";
import { useMealPlan } from "@/hooks/useMealPlan";
import { ActivityLevel, DietaryPreference } from "@/types";

interface TripConfigProps {
  onNext: () => void;
}

const TripConfig = ({ onNext }: TripConfigProps) => {
  const { mealPlan, updateMealPlan, generateMealPlan } = useMealPlan();
  
  const handleDietaryChange = (preference: DietaryPreference) => {
    const currentPreferences = [...mealPlan.dietaryPreferences];
    const index = currentPreferences.indexOf(preference);
    
    if (index > -1) {
      currentPreferences.splice(index, 1);
    } else {
      currentPreferences.push(preference);
    }
    
    updateMealPlan({ dietaryPreferences: currentPreferences });
  };
  
  const handleGenerateMealPlan = async () => {
    await generateMealPlan();
    onNext();
  };
  
  return (
    <section id="tripConfig" className="mb-8 bg-white rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.05)] p-6">
      <h2 className="text-2xl font-semibold mb-6">Trip Details</h2>
      
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-[#495057] mb-2">Trip Name</label>
          <input 
            type="text" 
            placeholder="Weekend Hiking Trip" 
            className="w-full px-4 py-2.5 rounded-lg border border-[#CED4DA] focus:outline-none focus:ring-2 focus:ring-[#52B788] focus:border-transparent"
            value={mealPlan.name}
            onChange={(e) => updateMealPlan({ name: e.target.value })}
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-[#495057] mb-2">Number of People</label>
          <div className="flex items-center">
            <button 
              className="bg-[#E9ECEF] hover:bg-[#CED4DA] text-[#495057] px-3 py-2 rounded-l-lg border border-[#CED4DA] transition-all"
              onClick={() => updateMealPlan({ people: Math.max(1, mealPlan.people - 1) })}
            >
              <i className="ri-subtract-line"></i>
            </button>
            <input 
              type="number" 
              value={mealPlan.people} 
              min="1" 
              max="20" 
              className="w-20 text-center py-2 border-t border-b border-[#CED4DA] focus:outline-none"
              onChange={(e) => updateMealPlan({ people: parseInt(e.target.value) || 1 })}
            />
            <button 
              className="bg-[#E9ECEF] hover:bg-[#CED4DA] text-[#495057] px-3 py-2 rounded-r-lg border border-[#CED4DA] transition-all"
              onClick={() => updateMealPlan({ people: mealPlan.people + 1 })}
            >
              <i className="ri-add-line"></i>
            </button>
          </div>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-[#495057] mb-2">Trip Duration</label>
          <div className="flex flex-wrap gap-2">
            {[2, 3, 4, 5].map((days) => (
              <button 
                key={days}
                className={`px-4 py-2 rounded-lg ${mealPlan.days === days ? 'bg-[#2D6A4F] text-white' : 'bg-[#E9ECEF] text-[#495057]'}`}
                onClick={() => updateMealPlan({ days })}
              >
                {days} Days
              </button>
            ))}
            <button
              className={`px-4 py-2 rounded-lg ${mealPlan.days > 5 ? 'bg-[#2D6A4F] text-white' : 'bg-[#E9ECEF] text-[#495057]'}`}
              onClick={() => updateMealPlan({ days: 6 })}
            >
              5+ Days
            </button>
          </div>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-[#495057] mb-2">Activity Level</label>
          <div className="relative w-full">
            <select 
              className="block w-full px-4 py-2.5 rounded-lg border border-[#CED4DA] focus:outline-none focus:ring-2 focus:ring-[#52B788] focus:border-transparent appearance-none"
              value={mealPlan.activityLevel}
              onChange={(e) => updateMealPlan({ activityLevel: e.target.value as ActivityLevel })}
            >
              <option value="low">Low Intensity (1-2 miles/day)</option>
              <option value="moderate">Moderate (5-10 miles/day)</option>
              <option value="high">High (10-15 miles/day)</option>
              <option value="extreme">Extreme (15+ miles/day)</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-[#495057]">
              <i className="ri-arrow-down-s-line"></i>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-6">
        <h3 className="text-lg font-medium mb-3">Dietary Restrictions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { id: 'vegetarian', label: 'Vegetarian' },
            { id: 'vegan', label: 'Vegan' },
            { id: 'gluten-free', label: 'Gluten Free' },
            { id: 'dairy-free', label: 'Dairy Free' },
            { id: 'nut-free', label: 'Nut Free' },
            { id: 'keto', label: 'Keto' },
            { id: 'paleo', label: 'Paleo' },
            { id: 'low-sodium', label: 'Low Sodium' }
          ].map((option) => (
            <div key={option.id} className="relative">
              <input 
                type="checkbox" 
                id={option.id} 
                className="hidden peer" 
                checked={mealPlan.dietaryPreferences.includes(option.id as DietaryPreference)}
                onChange={() => handleDietaryChange(option.id as DietaryPreference)}
              />
              <label 
                htmlFor={option.id} 
                className={`flex items-center p-3 rounded-lg border ${mealPlan.dietaryPreferences.includes(option.id as DietaryPreference) ? 'border-[#2D6A4F] bg-[#52B788]/10' : 'border-[#CED4DA]'} hover:bg-[#F8FAF9] cursor-pointer transition-all`}
              >
                <div className={`w-5 h-5 border ${mealPlan.dietaryPreferences.includes(option.id as DietaryPreference) ? 'border-[#2D6A4F] bg-[#2D6A4F]' : 'border-[#CED4DA]'} rounded-md flex items-center justify-center mr-3`}>
                  {mealPlan.dietaryPreferences.includes(option.id as DietaryPreference) && (
                    <i className="ri-check-line text-white"></i>
                  )}
                </div>
                <span>{option.label}</span>
              </label>
            </div>
          ))}
        </div>
      </div>
      
      <div className="mt-6">
        <h3 className="text-lg font-medium mb-3">Nutrition Targets</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <div>
            <div className="flex justify-between">
              <label className="text-sm font-medium text-[#495057]">Daily Calories</label>
              <span className="text-sm text-[#1B4332]">{mealPlan.dailyCalories} kcal</span>
            </div>
            <input 
              type="range" 
              min="1500" 
              max="4000" 
              step="100" 
              value={mealPlan.dailyCalories} 
              className="w-full h-2 bg-[#E9ECEF] rounded-lg appearance-none cursor-pointer accent-[#52B788] mt-2"
              onChange={(e) => updateMealPlan({ dailyCalories: parseInt(e.target.value) })}
            />
            <div className="flex justify-between text-xs text-[#495057] mt-1">
              <span>1,500</span>
              <span>4,000</span>
            </div>
          </div>
          
          <div>
            <div className="flex justify-between">
              <label className="text-sm font-medium text-[#495057]">Protein</label>
              <span className="text-sm text-[#1B4332]">{mealPlan.proteinPercentage}%</span>
            </div>
            <input 
              type="range" 
              min="10" 
              max="40" 
              step="5" 
              value={mealPlan.proteinPercentage} 
              className="w-full h-2 bg-[#E9ECEF] rounded-lg appearance-none cursor-pointer accent-[#52B788] mt-2"
              onChange={(e) => {
                const proteinPercentage = parseInt(e.target.value);
                const maxCarbs = 100 - proteinPercentage - 10; // Minimum 10% fat
                const carbsPercentage = Math.min(mealPlan.carbsPercentage, maxCarbs);
                const fatPercentage = 100 - proteinPercentage - carbsPercentage;
                updateMealPlan({ proteinPercentage, carbsPercentage, fatPercentage });
              }}
            />
            <div className="flex justify-between text-xs text-[#495057] mt-1">
              <span>10%</span>
              <span>40%</span>
            </div>
          </div>
          
          <div>
            <div className="flex justify-between">
              <label className="text-sm font-medium text-[#495057]">Carbohydrates</label>
              <span className="text-sm text-[#1B4332]">{mealPlan.carbsPercentage}%</span>
            </div>
            <input 
              type="range" 
              min="30" 
              max="70" 
              step="5" 
              value={mealPlan.carbsPercentage} 
              className="w-full h-2 bg-[#E9ECEF] rounded-lg appearance-none cursor-pointer accent-[#52B788] mt-2"
              onChange={(e) => {
                const carbsPercentage = parseInt(e.target.value);
                const maxProtein = 100 - carbsPercentage - 10; // Minimum 10% fat
                const proteinPercentage = Math.min(mealPlan.proteinPercentage, maxProtein);
                const fatPercentage = 100 - proteinPercentage - carbsPercentage;
                updateMealPlan({ proteinPercentage, carbsPercentage, fatPercentage });
              }}
            />
            <div className="flex justify-between text-xs text-[#495057] mt-1">
              <span>30%</span>
              <span>70%</span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-6 flex justify-end">
        <button 
          onClick={handleGenerateMealPlan}
          className="bg-[#2D6A4F] hover:bg-[#1B4332] text-white font-medium px-5 py-2.5 rounded-lg transition-all flex items-center"
        >
          <i className="ri-restaurant-line mr-2"></i>
          Generate Meal Plan
        </button>
      </div>
    </section>
  );
};

export default TripConfig;
