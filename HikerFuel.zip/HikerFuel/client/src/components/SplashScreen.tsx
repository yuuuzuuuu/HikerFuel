import { useEffect, useState } from "react";
// Gunakan teknik import relatif biasa karena ada masalah dengan alias
import fintrackLogo from "../assets/fintrack-logo.png";

const SplashScreen = () => {
  const [show, setShow] = useState(true);

  useEffect(() => {
    // Saat splash screen aktif, nonaktifkan scrolling
    if (show) {
      document.body.style.overflow = 'hidden';
    }
    
    const timer = setTimeout(() => {
      setShow(false);
      // Kembalikan scrolling saat splash screen hilang
      document.body.style.overflow = '';
    }, 2500); // Show splash screen for 2.5 seconds

    return () => {
      clearTimeout(timer);
      document.body.style.overflow = '';
    };
  }, [show]);

  if (!show) return null;

  return (
    <div className="fixed inset-0 w-screen h-screen bg-gradient-to-br from-primary to-emerald-700 flex flex-col items-center justify-center z-[9999] splash-screen">
      <div className="animate-pulse">
        <img 
          src={fintrackLogo} 
          alt="FinTrack Logo" 
          className="w-48 sm:w-56 h-auto mb-8"
        />
      </div>
      <div className="text-white text-center">
        <p className="text-xl sm:text-2xl font-medium mb-10">Aplikasi Keuangan Pribadimu</p>
        <div className="w-56 sm:w-64 h-2 bg-white/30 rounded-full mx-auto overflow-hidden">
          <div 
            className="h-full bg-white rounded-full progress-bar"
          />
        </div>
      </div>
    </div>
  );
};

export default SplashScreen;