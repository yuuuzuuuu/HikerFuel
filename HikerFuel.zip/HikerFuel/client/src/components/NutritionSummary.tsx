import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useMealPlan } from "@/hooks/useMealPlan";
import { Recipe } from "@/types";

interface NutritionSummaryProps {
  onNext: () => void;
}

const NutritionSummary = ({ onNext }: NutritionSummaryProps) => {
  const { mealPlan } = useMealPlan();
  
  // Fetch all recipes to calculate nutrition
  const { data: recipes = [], isLoading } = useQuery<Recipe[]>({
    queryKey: ['/api/recipes'],
  });
  
  // Calculate total nutrition from meal plan
  const nutrition = useMemo(() => {
    if (!recipes.length || !mealPlan.meals.length) {
      return {
        totalCalories: mealPlan.dailyCalories,
        protein: Math.round((mealPlan.dailyCalories * mealPlan.proteinPercentage / 100) / 4), // 4 calories per gram of protein
        carbs: Math.round((mealPlan.dailyCalories * mealPlan.carbsPercentage / 100) / 4), // 4 calories per gram of carbs
        fat: Math.round((mealPlan.dailyCalories * mealPlan.fatPercentage / 100) / 9), // 9 calories per gram of fat
        mealDistribution: {
          breakfast: { calories: 0, percentage: 0 },
          lunch: { calories: 0, percentage: 0 },
          dinner: { calories: 0, percentage: 0 },
          snack: { calories: 0, percentage: 0 }
        }
      };
    }
    
    // Calculate actual nutrition from selected meals
    let totalCalories = 0;
    let totalProtein = 0;
    let totalCarbs = 0;
    let totalFat = 0;
    
    const mealDistribution = {
      breakfast: { calories: 0, percentage: 0 },
      lunch: { calories: 0, percentage: 0 },
      dinner: { calories: 0, percentage: 0 },
      snack: { calories: 0, percentage: 0 }
    };
    
    // Calculate for each day then average
    for (let day = 0; day < mealPlan.days; day++) {
      const dayMeals = mealPlan.meals.filter(meal => meal.dayIndex === day);
      
      dayMeals.forEach(meal => {
        const recipe = recipes.find(r => r.id === meal.recipeId);
        if (recipe) {
          totalCalories += recipe.calories;
          totalProtein += recipe.protein;
          totalCarbs += recipe.carbs;
          totalFat += recipe.fat;
          
          // Add to meal distribution
          mealDistribution[meal.mealType].calories += recipe.calories;
        }
      });
    }
    
    // Average across days
    totalCalories = Math.round(totalCalories / mealPlan.days);
    totalProtein = Math.round(totalProtein / mealPlan.days);
    totalCarbs = Math.round(totalCarbs / mealPlan.days);
    totalFat = Math.round(totalFat / mealPlan.days);
    
    // Calculate percentages for meal distribution
    Object.keys(mealDistribution).forEach(key => {
      mealDistribution[key as keyof typeof mealDistribution].calories = 
        Math.round(mealDistribution[key as keyof typeof mealDistribution].calories / mealPlan.days);
        
      mealDistribution[key as keyof typeof mealDistribution].percentage = 
        Math.round((mealDistribution[key as keyof typeof mealDistribution].calories / totalCalories) * 100);
    });
    
    return {
      totalCalories,
      protein: totalProtein,
      carbs: totalCarbs,
      fat: totalFat,
      mealDistribution
    };
  }, [recipes, mealPlan]);
  
  if (isLoading) {
    return (
      <section className="mb-8">
        <div className="flex justify-center p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#2D6A4F]"></div>
        </div>
      </section>
    );
  }
  
  return (
    <section className="mb-8 bg-white rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.05)] p-6">
      <h2 className="text-2xl font-semibold mb-6">Nutrition Summary</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="p-4 rounded-lg bg-[#F8FAF9]">
          <div className="text-sm text-[#495057] mb-1">Total Calories</div>
          <div className="text-2xl font-bold text-[#343A40]">{nutrition.totalCalories.toLocaleString()}</div>
          <div className="text-xs text-[#495057]">per person/day</div>
        </div>
        
        <div className="p-4 rounded-lg bg-[#F8FAF9]">
          <div className="text-sm text-[#495057] mb-1">Protein</div>
          <div className="flex items-end">
            <span className="text-2xl font-bold text-[#343A40] mr-1">{nutrition.protein}g</span>
            <span className="text-sm text-[#495057]">({mealPlan.proteinPercentage}%)</span>
          </div>
          <div className="w-full h-2 bg-[#CED4DA] rounded-full mt-2">
            <div className="h-full bg-[#2D6A4F] rounded-full" style={{ width: `${mealPlan.proteinPercentage}%` }}></div>
          </div>
        </div>
        
        <div className="p-4 rounded-lg bg-[#F8FAF9]">
          <div className="text-sm text-[#495057] mb-1">Carbohydrates</div>
          <div className="flex items-end">
            <span className="text-2xl font-bold text-[#343A40] mr-1">{nutrition.carbs}g</span>
            <span className="text-sm text-[#495057]">({mealPlan.carbsPercentage}%)</span>
          </div>
          <div className="w-full h-2 bg-[#CED4DA] rounded-full mt-2">
            <div className="h-full bg-[#9C6644] rounded-full" style={{ width: `${mealPlan.carbsPercentage}%` }}></div>
          </div>
        </div>
        
        <div className="p-4 rounded-lg bg-[#F8FAF9]">
          <div className="text-sm text-[#495057] mb-1">Fats</div>
          <div className="flex items-end">
            <span className="text-2xl font-bold text-[#343A40] mr-1">{nutrition.fat}g</span>
            <span className="text-sm text-[#495057]">({mealPlan.fatPercentage}%)</span>
          </div>
          <div className="w-full h-2 bg-[#CED4DA] rounded-full mt-2">
            <div className="h-full bg-[#E9C46A] rounded-full" style={{ width: `${mealPlan.fatPercentage}%` }}></div>
          </div>
        </div>
      </div>
      
      <div className="bg-[#F8FAF9] rounded-lg p-4 mb-6">
        <h3 className="text-lg font-medium mb-3">Daily Distribution</h3>
        <div className="flex flex-col md:flex-row">
          <div className="flex-1 mb-4 md:mb-0 md:mr-6">
            <div className="relative h-48 flex items-center justify-center">
              <svg width="180" height="180" viewBox="0 0 180 180">
                <circle
                  cx="90"
                  cy="90"
                  r="80"
                  fill="none"
                  stroke="#E9ECEF"
                  strokeWidth="20"
                />
                
                {/* Breakfast */}
                <circle
                  cx="90"
                  cy="90"
                  r="80"
                  fill="none"
                  stroke="#E9C46A"
                  strokeWidth="20"
                  strokeDasharray={`${nutrition.mealDistribution.breakfast.percentage * 5.03} 503`}
                  strokeDashoffset="0"
                  transform="rotate(-90 90 90)"
                />
                
                {/* Lunch */}
                <circle
                  cx="90"
                  cy="90"
                  r="80"
                  fill="none"
                  stroke="#9C6644"
                  strokeWidth="20"
                  strokeDasharray={`${nutrition.mealDistribution.lunch.percentage * 5.03} 503`}
                  strokeDashoffset={`${-nutrition.mealDistribution.breakfast.percentage * 5.03}`}
                  transform="rotate(-90 90 90)"
                />
                
                {/* Dinner */}
                <circle
                  cx="90"
                  cy="90"
                  r="80"
                  fill="none"
                  stroke="#495057"
                  strokeWidth="20"
                  strokeDasharray={`${nutrition.mealDistribution.dinner.percentage * 5.03} 503`}
                  strokeDashoffset={`${-(nutrition.mealDistribution.breakfast.percentage + nutrition.mealDistribution.lunch.percentage) * 5.03}`}
                  transform="rotate(-90 90 90)"
                />
                
                {/* Snack */}
                <circle
                  cx="90"
                  cy="90"
                  r="80"
                  fill="none"
                  stroke="#52B788"
                  strokeWidth="20"
                  strokeDasharray={`${nutrition.mealDistribution.snack.percentage * 5.03} 503`}
                  strokeDashoffset={`${-(nutrition.mealDistribution.breakfast.percentage + nutrition.mealDistribution.lunch.percentage + nutrition.mealDistribution.dinner.percentage) * 5.03}`}
                  transform="rotate(-90 90 90)"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-[#495057] text-sm">Calories by Meal</div>
                </div>
              </div>
            </div>
          </div>
          <div className="flex-1">
            <div className="grid grid-cols-1 gap-2">
              <div className="flex justify-between items-center p-2 rounded-lg bg-white">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-[#E9C46A] mr-2"></div>
                  <span className="text-sm">Breakfast</span>
                </div>
                <div className="flex items-center">
                  <span className="text-sm font-medium">{nutrition.mealDistribution.breakfast.calories.toLocaleString()} kcal</span>
                  <span className="text-xs text-[#495057] ml-1">({nutrition.mealDistribution.breakfast.percentage}%)</span>
                </div>
              </div>
              <div className="flex justify-between items-center p-2 rounded-lg bg-white">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-[#9C6644] mr-2"></div>
                  <span className="text-sm">Lunch</span>
                </div>
                <div className="flex items-center">
                  <span className="text-sm font-medium">{nutrition.mealDistribution.lunch.calories.toLocaleString()} kcal</span>
                  <span className="text-xs text-[#495057] ml-1">({nutrition.mealDistribution.lunch.percentage}%)</span>
                </div>
              </div>
              <div className="flex justify-between items-center p-2 rounded-lg bg-white">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-[#495057] mr-2"></div>
                  <span className="text-sm">Dinner</span>
                </div>
                <div className="flex items-center">
                  <span className="text-sm font-medium">{nutrition.mealDistribution.dinner.calories.toLocaleString()} kcal</span>
                  <span className="text-xs text-[#495057] ml-1">({nutrition.mealDistribution.dinner.percentage}%)</span>
                </div>
              </div>
              <div className="flex justify-between items-center p-2 rounded-lg bg-white">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-[#52B788] mr-2"></div>
                  <span className="text-sm">Snacks</span>
                </div>
                <div className="flex items-center">
                  <span className="text-sm font-medium">{nutrition.mealDistribution.snack.calories.toLocaleString()} kcal</span>
                  <span className="text-xs text-[#495057] ml-1">({nutrition.mealDistribution.snack.percentage}%)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-[#52B788]/10 rounded-lg p-4">
        <div className="flex items-start">
          <i className="ri-information-line text-[#1B4332] mt-0.5 mr-3"></i>
          <div>
            <h4 className="font-medium text-[#1B4332] mb-1">Nutrition Analysis</h4>
            <p className="text-sm text-[#495057]">
              Your meal plan is well-balanced for a {mealPlan.activityLevel} activity level. 
              {mealPlan.activityLevel === 'high' || mealPlan.activityLevel === 'extreme' ? 
                " You may want to increase protein intake slightly if planning more strenuous activities." : 
                " The current plan provides sufficient energy and nutrients for your planned activity level."}
              The current plan provides sufficient energy and nutrients for {mealPlan.days} days of {mealPlan.activityLevel} hiking.
            </p>
          </div>
        </div>
      </div>
      
      <div className="flex justify-end mt-6">
        <button 
          onClick={onNext}
          className="bg-[#2D6A4F] hover:bg-[#1B4332] text-white font-medium px-5 py-2.5 rounded-lg transition-all flex items-center"
        >
          Continue to Shopping List
          <i className="ri-arrow-right-line ml-2"></i>
        </button>
      </div>
    </section>
  );
};

export default NutritionSummary;
