import { Recipe } from "@/types";

interface MealDetailModalProps {
  show: boolean;
  onClose: () => void;
  recipe: Recipe;
}

const MealDetailModal = ({ show, onClose, recipe }: MealDetailModalProps) => {
  if (!show) return null;

  return (
    <div
      className="fixed inset-0 bg-[#343A40]/50 flex items-center justify-center z-50"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="modal-container w-full max-w-lg mx-4">
        <div className="bg-white rounded-xl overflow-hidden shadow-lg max-h-[90vh] overflow-y-auto">
          <div className="relative">
            <img
              src={recipe.imageUrl}
              alt={recipe.name}
              className="w-full h-48 object-cover"
            />
            <button
              className="absolute top-4 right-4 bg-white/80 hover:bg-white text-[#495057] rounded-full p-2 transition-all"
              onClick={onClose}
            >
              <i className="ri-close-line text-xl"></i>
            </button>
          </div>

          <div className="p-6">
            <h3 className="text-xl font-semibold mb-2">{recipe.name}</h3>

            <div className="flex flex-wrap gap-2 mb-4">
              {(recipe.dietaryTags as string[]).map((tag) => (
                <span
                  key={tag}
                  className="bg-[#52B788]/20 text-[#1B4332] text-xs px-2 py-0.5 rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>

            <div className="grid grid-cols-4 gap-4 mb-6">
              <div className="text-center p-2 bg-[#F8FAF9] rounded-lg">
                <div className="text-sm text-[#495057]">Calories</div>
                <div className="font-medium">{recipe.calories} kcal</div>
              </div>
              <div className="text-center p-2 bg-[#F8FAF9] rounded-lg">
                <div className="text-sm text-[#495057]">Protein</div>
                <div className="font-medium">{recipe.protein}g</div>
              </div>
              <div className="text-center p-2 bg-[#F8FAF9] rounded-lg">
                <div className="text-sm text-[#495057]">Carbs</div>
                <div className="font-medium">{recipe.carbs}g</div>
              </div>
              <div className="text-center p-2 bg-[#F8FAF9] rounded-lg">
                <div className="text-sm text-[#495057]">Fat</div>
                <div className="font-medium">{recipe.fat}g</div>
              </div>
            </div>

            <div className="mb-6">
              <h4 className="font-medium mb-2">Ingredients (per serving)</h4>
              <ul className="space-y-2 text-sm">
                {(recipe.ingredients as string[]).map((ingredient, index) => (
                  <li key={index} className="flex items-center">
                    <i className="ri-checkbox-circle-line text-[#2D6A4F] mr-2"></i>
                    <span>{ingredient}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mb-6">
              <h4 className="font-medium mb-2">Preparation</h4>
              <ol className="space-y-2 text-sm">
                {(recipe.preparation as string[]).map((step, index) => (
                  <li key={index} className="flex">
                    <span className="bg-[#52B788]/20 text-[#1B4332] rounded-full w-6 h-6 flex items-center justify-center mr-2 flex-shrink-0">
                      {index + 1}
                    </span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            <div className="bg-[#F8FAF9] p-4 rounded-lg mb-6">
              <h4 className="font-medium mb-2 flex items-center">
                <i className="ri-lightbulb-flash-line text-[#E9C46A] mr-2"></i>
                Trail Tips
              </h4>
              <p className="text-sm text-[#495057]">
                {recipe.mealType === "breakfast" &&
                  "Pre-mix dry ingredients at home in a zip-lock bag for easier preparation on the trail. For extra energy, add a tablespoon of nut butter or coconut oil to increase calorie content."}
                {recipe.mealType === "lunch" &&
                  "Prepare any chopping or mixing ahead of time and store in portable containers. If using wraps, keep fillings separate until ready to eat to prevent sogginess."}
                {recipe.mealType === "dinner" &&
                  "Plan to cook this meal when you have time to relax at camp. You can pre-measure and package spices in small baggies to reduce weight and bulk while hiking."}
                {recipe.mealType === "snack" &&
                  "Portion into individual servings before your trip for easy access during breaks. Store in an accessible pocket of your pack so you don't need to stop and unpack."}
              </p>
            </div>

            <div className="flex justify-between">
              <button className="flex items-center text-[#495057]">
                <i className="ri-star-line mr-1"></i>
                <span>Save Recipe</span>
              </button>
              <button className="bg-[#2D6A4F] hover:bg-[#1B4332] text-white px-4 py-2 rounded-lg transition-all">
                Add to Meal Plan
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MealDetailModal;
