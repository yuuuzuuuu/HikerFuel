import { Link, useLocation } from "wouter";
import { 
  CircleDollarSign, 
  Receipt, 
  UserCircle, 
  BarChart3, 
  Home, 
  Bell, 
  Settings, 
  Wallet, 
  CreditCard, 
  ChevronRight,
  Menu,
  X
} from "lucide-react";
import { useState } from "react";
import fintrackLogo from "../../assets/fintrack-logo.png";
import { useNotifications } from "../../context/NotificationContext";
import NotificationCenter from "../NotificationCenter";

const Header = () => {
  const [location] = useLocation();
  const [quickActionsOpen, setQuickActionsOpen] = useState(false);
  const [notificationCenterOpen, setNotificationCenterOpen] = useState(false);

  // Menggunakan context notifikasi
  const { notifications, unreadCount, markAllAsRead } = useNotifications();

  const toggleQuickActions = () => {
    setQuickActionsOpen(!quickActionsOpen);
    
    // Tutup notification center jika terbuka
    if (notificationCenterOpen) {
      setNotificationCenterOpen(false);
    }
  };

  const closeQuickActions = () => {
    setQuickActionsOpen(false);
  };
  
  const toggleNotificationCenter = () => {
    setNotificationCenterOpen(!notificationCenterOpen);
    
    // Tutup quick actions jika terbuka
    if (quickActionsOpen) {
      setQuickActionsOpen(false);
    }
    
    // Tandai semua notifikasi sudah dibaca saat notifikasi dibuka
    if (!notificationCenterOpen) {
      markAllAsRead();
    }
  };
  
  // Ambil 2 notifikasi teratas untuk ditampilkan di menu quick actions
  const topNotifications = notifications.slice(0, 2);

  return (
    <>
      {/* Top Header */}
      <header className="sticky top-0 z-40 bg-background shadow-sm">
        <div className="container mx-auto px-4 py-2 flex justify-between items-center">
          <Link href="/">
            <div className="flex items-center cursor-pointer">
              <img 
                src={fintrackLogo} 
                alt="FinTrack Logo" 
                className="h-8 sm:h-9 mr-2" 
              />
              <h1 className="text-lg sm:text-xl font-semibold">FinTrack</h1>
            </div>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/expenses">
              <div className={`flex items-center gap-1.5 transition-all cursor-pointer ${location === '/expenses' ? 'text-primary font-medium' : 'text-muted-foreground hover:text-primary'}`}>
                <Receipt className="h-4 w-4" />
                <span>Pengeluaran</span>
              </div>
            </Link>
            <Link href="/budgets">
              <div className={`flex items-center gap-1.5 transition-all cursor-pointer ${location === '/budgets' ? 'text-primary font-medium' : 'text-muted-foreground hover:text-primary'}`}>
                <CircleDollarSign className="h-4 w-4" />
                <span>Budget</span>
              </div>
            </Link>
            <Link href="/report">
              <div className={`flex items-center gap-1.5 transition-all cursor-pointer ${location === '/report' ? 'text-primary font-medium' : 'text-muted-foreground hover:text-primary'}`}>
                <BarChart3 className="h-4 w-4" />
                <span>Laporan</span>
              </div>
            </Link>
            <Link href="/bank-accounts">
              <div className={`flex items-center gap-1.5 transition-all cursor-pointer ${location === '/bank-accounts' ? 'text-primary font-medium' : 'text-muted-foreground hover:text-primary'}`}>
                <CreditCard className="h-4 w-4" />
                <span>Rekening</span>
              </div>
            </Link>
            <Link href="/profile">
              <div className={`flex items-center gap-1.5 transition-all cursor-pointer ${location === '/profile' ? 'text-primary font-medium' : 'text-muted-foreground hover:text-primary'}`}>
                <UserCircle className="h-5 w-5" />
                <span>Profil</span>
              </div>
            </Link>
          </nav>
          
          {/* Mobile Quick Actions */}
          <div className="md:hidden flex items-center gap-3">
            {/* Tombol notifikasi dengan indikator */}
            <div className="relative">
              <button 
                onClick={toggleNotificationCenter}
                className="text-muted-foreground hover:text-primary p-1 rounded-full hover:bg-gray-100"
                aria-label="Notifikasi"
              >
                <Bell className="h-5 w-5" />
              </button>
              
              {/* Indikator notifikasi pada ikon Bell */}
              {unreadCount > 0 && (
                <div className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {unreadCount}
                </div>
              )}
            </div>
            
            {/* Tombol Menu */}
            <button 
              onClick={toggleQuickActions}
              className="text-muted-foreground hover:text-primary p-1 rounded-full hover:bg-gray-100"
              aria-label="Menu"
            >
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
        
        {/* Pusat Notifikasi */}
        {notificationCenterOpen && (
          <div className="fixed inset-0 bg-black/20 z-50 flex justify-center items-start md:items-center">
            <div className="bg-background rounded-lg shadow-lg w-full max-w-md mt-14 md:mt-0 mx-4 max-h-[90vh] overflow-hidden">
              <NotificationCenter onClose={() => setNotificationCenterOpen(false)} />
            </div>
          </div>
        )}
        
        {/* Mobile Quick Actions Menu */}
        {quickActionsOpen && (
          <div className="md:hidden bg-background border-t border-border">
            <div className="container mx-auto px-4 py-2 flex flex-col divide-y divide-gray-100">
              {/* Bagian Notifikasi */}
              <div className="py-3">
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center gap-3">
                    <Bell className="h-5 w-5 text-primary" />
                    <span className="text-sm font-medium">Notifikasi</span>
                  </div>
                  {/* Tombol Lihat Semua */}
                  <button 
                    className="text-xs text-primary"
                    onClick={(e) => {
                      e.preventDefault();
                      setQuickActionsOpen(false);
                      setNotificationCenterOpen(true);
                    }}
                  >
                    Lihat Semua
                  </button>
                </div>
                
                {/* Ringkasan Notifikasi */}
                <div className="space-y-2 mt-1">
                  {topNotifications.length > 0 ? (
                    topNotifications.map(notification => (
                      <div 
                        key={notification.id} 
                        className={`p-2 rounded-md ${notification.read ? 'bg-gray-50' : notification.type === 'warning' ? 'bg-amber-50' : notification.type === 'info' ? 'bg-blue-50' : notification.type === 'success' ? 'bg-green-50' : 'bg-red-50'}`}
                      >
                        <div className="flex gap-2">
                          <div className={`rounded-full ${
                            notification.type === 'warning' 
                              ? 'bg-amber-500' 
                              : notification.type === 'info' 
                                ? 'bg-blue-500' 
                                : notification.type === 'success' 
                                  ? 'bg-green-500' 
                                  : 'bg-red-500'
                          } text-white p-1.5 flex-shrink-0 w-6 h-6 flex items-center justify-center text-xs`}>
                            {notification.type === 'warning' ? '!' : notification.type === 'info' ? 'i' : notification.type === 'success' ? '✓' : '!'}
                          </div>
                          <div>
                            <p className="text-xs font-medium">{notification.title}</p>
                            <p className="text-xs text-muted-foreground">{notification.message}</p>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-2">
                      <p className="text-xs text-muted-foreground">Tidak ada notifikasi</p>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Menu Lainnya */}
              <Link href="/bank-accounts">
                <div className="py-3 flex justify-between items-center" onClick={closeQuickActions}>
                  <div className="flex items-center gap-3">
                    <CreditCard className="h-5 w-5 text-primary" />
                    <span className="text-sm">Hubungkan ke Rekening Bank</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </Link>
              
              <Link href="/bank-accounts?tab=ewallet">
                <div className="py-3 flex justify-between items-center" onClick={closeQuickActions}>
                  <div className="flex items-center gap-3">
                    <Wallet className="h-5 w-5 text-primary" />
                    <span className="text-sm">Cek Saldo E-Wallet</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </Link>
              
              <Link href="/profile">
                <div className="py-3 flex justify-between items-center" onClick={closeQuickActions}>
                  <div className="flex items-center gap-3">
                    <Settings className="h-5 w-5 text-primary" />
                    <span className="text-sm">Pengaturan Aplikasi</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </Link>
            </div>
          </div>
        )}
      </header>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-background border-t border-border px-2 py-1 flex justify-around items-center shadow-lg">
        <Link href="/">
          <div className={`flex flex-col items-center py-1 px-2 ${location === '/' ? 'text-primary' : 'text-muted-foreground'}`}>
            <Home className="h-5 w-5 mb-0.5" />
            <span className="text-[10px]">Beranda</span>
          </div>
        </Link>
        <Link href="/expenses">
          <div className={`flex flex-col items-center py-1 px-2 ${location === '/expenses' ? 'text-primary' : 'text-muted-foreground'}`}>
            <Receipt className="h-5 w-5 mb-0.5" />
            <span className="text-[10px]">Pengeluaran</span>
          </div>
        </Link>
        <Link href="/budgets">
          <div className={`flex flex-col items-center py-1 px-2 ${location === '/budgets' ? 'text-primary' : 'text-muted-foreground'}`}>
            <CircleDollarSign className="h-5 w-5 mb-0.5" />
            <span className="text-[10px]">Budget</span>
          </div>
        </Link>
        <Link href="/report">
          <div className={`flex flex-col items-center py-1 px-2 ${location === '/report' ? 'text-primary' : 'text-muted-foreground'}`}>
            <BarChart3 className="h-5 w-5 mb-0.5" />
            <span className="text-[10px]">Laporan</span>
          </div>
        </Link>
        <Link href="/profile">
          <div className={`flex flex-col items-center py-1 px-2 ${location === '/profile' ? 'text-primary' : 'text-muted-foreground'}`}>
            <UserCircle className="h-5 w-5 mb-0.5" />
            <span className="text-[10px]">Profil</span>
          </div>
        </Link>
      </nav>
    </>
  );
};

export default Header;
