import React from "react";

interface FooterProps {
  className?: string;
}

const Footer: React.FC<FooterProps> = ({ className = "" }) => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className={`py-6 bg-background border-t ${className}`}>
      <div className="container mx-auto px-4">
        <div className="text-center text-sm text-muted-foreground">
          <p>© {currentYear} FinTrack. Semua hak dilindungi.</p>
          <p className="mt-2">Aplikasi manajemen keuangan yang mudah digunakan untuk mengontrol pengeluaran Anda.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
