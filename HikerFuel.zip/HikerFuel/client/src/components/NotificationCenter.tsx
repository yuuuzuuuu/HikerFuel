import { Bell, Check, X, ChevronRight } from "lucide-react";
import { Link } from "wouter";
import { useNotifications } from "../context/NotificationContext";

// Tipe data untuk notifikasi
export interface Notification {
  id: number;
  title: string;
  message: string;
  type: "info" | "warning" | "success" | "error";
  read: boolean;
  date: Date;
  link?: string;
}

interface NotificationCenterProps {
  onClose: () => void;
}

const NotificationCenter = ({ onClose }: NotificationCenterProps) => {
  // Menggunakan context untuk notifikasi
  const { 
    notifications, 
    markAsRead, 
    markAllAsRead 
  } = useNotifications();

  // Filter notifikasi berdasarkan status baca
  const unreadNotifications = notifications.filter(notification => !notification.read);
  const readNotifications = notifications.filter(notification => notification.read);

  // Fungsi untuk menampilkan waktu relatif (misalnya "2 jam yang lalu")
  const getRelativeTime = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHour = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHour / 24);

    if (diffDay > 0) {
      return `${diffDay} hari yang lalu`;
    } else if (diffHour > 0) {
      return `${diffHour} jam yang lalu`;
    } else if (diffMin > 0) {
      return `${diffMin} menit yang lalu`;
    } else {
      return "Baru saja";
    }
  };

  // Render ikon berdasarkan tipe notifikasi
  const renderIcon = (type: Notification["type"]) => {
    switch (type) {
      case "info":
        return <div className="rounded-full bg-blue-500 text-white p-1.5 flex-shrink-0 w-7 h-7 flex items-center justify-center text-xs">i</div>;
      case "warning":
        return <div className="rounded-full bg-amber-500 text-white p-1.5 flex-shrink-0 w-7 h-7 flex items-center justify-center text-xs">!</div>;
      case "success":
        return <div className="rounded-full bg-green-500 text-white p-1.5 flex-shrink-0 w-7 h-7 flex items-center justify-center text-xs">✓</div>;
      case "error":
        return <div className="rounded-full bg-red-500 text-white p-1.5 flex-shrink-0 w-7 h-7 flex items-center justify-center text-xs">!</div>;
      default:
        return <div className="rounded-full bg-gray-500 text-white p-1.5 flex-shrink-0 w-7 h-7 flex items-center justify-center text-xs">•</div>;
    }
  };

  // Render background color berdasarkan tipe notifikasi
  const getBackgroundColor = (type: Notification["type"], read: boolean) => {
    if (read) return "bg-gray-50";
    
    switch (type) {
      case "info":
        return "bg-blue-50";
      case "warning":
        return "bg-amber-50";
      case "success":
        return "bg-green-50";
      case "error":
        return "bg-red-50";
      default:
        return "bg-gray-50";
    }
  };

  // Render item notifikasi
  const renderNotificationItem = (notification: Notification) => {
    const bgColor = getBackgroundColor(notification.type, notification.read);
    
    const content = (
      <div className={`${bgColor} p-3 rounded-md mb-2 transition-all hover:shadow-sm`}>
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0">
            {renderIcon(notification.type)}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex justify-between items-start">
              <h4 className="text-sm font-medium truncate">{notification.title}</h4>
              <span className="text-xs text-gray-500 ml-2 whitespace-nowrap">
                {getRelativeTime(notification.date)}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">{notification.message}</p>
          </div>
          {!notification.read && (
            <button 
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                markAsRead(notification.id);
              }}
              className="text-gray-400 hover:text-primary p-1 rounded-full hover:bg-gray-100"
              aria-label="Tandai sudah dibaca"
            >
              <Check className="h-4 w-4" />
            </button>
          )}
        </div>
        {notification.link && (
          <div className="mt-2 flex justify-end">
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </div>
        )}
      </div>
    );

    return notification.link ? (
      <Link 
        key={notification.id} 
        href={notification.link}
        onClick={() => {
          markAsRead(notification.id);
          onClose();
        }}
      >
        {content}
      </Link>
    ) : (
      <div key={notification.id}>{content}</div>
    );
  };

  return (
    <div className="w-full overflow-hidden">
      <div className="py-3 px-4 border-b border-gray-100">
        <div className="flex justify-between items-center mb-2">
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            <h3 className="text-base font-semibold">Notifikasi</h3>
            {unreadNotifications.length > 0 && (
              <span className="bg-primary text-white text-xs px-2 py-0.5 rounded-full">
                {unreadNotifications.length}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {unreadNotifications.length > 0 && (
              <button 
                onClick={markAllAsRead}
                className="text-xs text-primary hover:underline"
              >
                Tandai semua sudah dibaca
              </button>
            )}
            <button 
              onClick={onClose}
              className="text-gray-400 hover:text-gray-500 p-1 rounded-full hover:bg-gray-100"
              aria-label="Tutup"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="overflow-y-auto max-h-[calc(80vh-70px)] p-3">
        {unreadNotifications.length === 0 && readNotifications.length === 0 && (
          <div className="text-center py-8">
            <Bell className="h-12 w-12 text-gray-300 mx-auto mb-2" />
            <p className="text-sm text-gray-500">Tidak ada notifikasi</p>
          </div>
        )}

        {/* Notifikasi belum dibaca */}
        {unreadNotifications.length > 0 && (
          <div className="mb-4">
            <h4 className="text-xs font-medium uppercase text-gray-500 mb-2">Belum dibaca</h4>
            {unreadNotifications.map(renderNotificationItem)}
          </div>
        )}

        {/* Notifikasi sudah dibaca */}
        {readNotifications.length > 0 && (
          <div>
            <h4 className="text-xs font-medium uppercase text-gray-500 mb-2">Sebelumnya</h4>
            {readNotifications.map(renderNotificationItem)}
          </div>
        )}
      </div>
    </div>
  );
};

export default NotificationCenter;