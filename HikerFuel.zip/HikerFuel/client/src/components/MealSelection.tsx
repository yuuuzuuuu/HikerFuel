import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useMealPlan } from "@/hooks/useMealPlan";
import { Recipe, MealType } from "@/types";

interface MealSelectionProps {
  onShowMealDetail: (recipe: Recipe) => void;
  onNext: () => void;
}

const MealSelection = ({ onShowMealDetail, onNext }: MealSelectionProps) => {
  const { mealPlan, updateMealPlan, addMealToDay, removeMealFromDay, getMealsForDay } = useMealPlan();
  const [currentDayIndex, setCurrentDayIndex] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterBy, setFilterBy] = useState("all");
  
  // Fetch recipes from the API
  const { data: recipes = [], isLoading } = useQuery<Recipe[]>({
    queryKey: ['/api/recipes', mealPlan.dietaryPreferences],
    queryFn: async () => {
      const queryParams = new URLSearchParams();
      mealPlan.dietaryPreferences.forEach(pref => {
        queryParams.append('dietary', pref);
      });
      const response = await fetch(`/api/recipes?${queryParams.toString()}`);
      if (!response.ok) {
        throw new Error('Failed to fetch recipes');
      }
      return response.json();
    }
  });
  
  const mealsForCurrentDay = getMealsForDay(currentDayIndex);
  
  const breakfastMeals = recipes.filter(recipe => recipe.mealType === 'breakfast');
  const lunchMeals = recipes.filter(recipe => recipe.mealType === 'lunch');
  const dinnerMeals = recipes.filter(recipe => recipe.mealType === 'dinner');
  const snackMeals = recipes.filter(recipe => recipe.mealType === 'snack');
  
  const addDay = () => {
    updateMealPlan({ days: mealPlan.days + 1 });
  };
  
  const calculateMealCalories = (mealType: MealType) => {
    const selectedMeal = mealsForCurrentDay.find(m => m.mealType === mealType);
    if (!selectedMeal) return 0;
    
    const recipe = recipes.find(r => r.id === selectedMeal.recipeId);
    return recipe ? recipe.calories : 0;
  };
  
  const getSelectedRecipe = (mealType: MealType) => {
    const selectedMeal = mealsForCurrentDay.find(m => m.mealType === mealType);
    if (!selectedMeal) return null;
    
    return recipes.find(r => r.id === selectedMeal.recipeId) || null;
  };
  
  const isRecipeSelected = (recipeId: number, mealType: MealType) => {
    return mealsForCurrentDay.some(meal => meal.recipeId === recipeId && meal.mealType === mealType);
  };
  
  const selectRecipe = (recipe: Recipe) => {
    // Remove any existing meal of this type for this day
    const existingMeal = mealsForCurrentDay.find(meal => meal.mealType === recipe.mealType);
    if (existingMeal) {
      removeMealFromDay(currentDayIndex, recipe.mealType);
    }
    
    // Add the new meal
    addMealToDay(currentDayIndex, recipe.mealType, recipe.id);
  };
  
  const handleNext = () => {
    onNext();
  };
  
  if (isLoading) {
    return (
      <section className="mb-8">
        <div className="flex justify-center p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#2D6A4F]"></div>
        </div>
      </section>
    );
  }
  
  return (
    <section className="mb-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <h2 className="text-2xl font-semibold mb-2 md:mb-0">Meal Selections</h2>
        <div className="flex items-center space-x-4">
          <div className="relative inline-block text-left">
            <button className="flex items-center justify-between w-full bg-white border border-[#CED4DA] rounded-lg px-4 py-2 text-sm font-medium">
              <span>Filter by</span>
              <i className="ri-arrow-down-s-line ml-2"></i>
            </button>
          </div>
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search meals..." 
              className="w-full px-4 py-2 pr-10 rounded-lg border border-[#CED4DA] focus:outline-none focus:ring-2 focus:ring-[#52B788] focus:border-transparent"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <i className="ri-search-line absolute right-3 top-2.5 text-[#495057]"></i>
          </div>
        </div>
      </div>

      {/* Days Tabs */}
      <div className="mb-6 overflow-x-auto">
        <div className="flex space-x-2 min-w-max">
          {Array.from({ length: mealPlan.days }).map((_, index) => (
            <button 
              key={index}
              className={`px-6 py-2 rounded-lg ${currentDayIndex === index ? 'bg-[#2D6A4F] text-white' : 'bg-[#E9ECEF] text-[#495057]'} font-medium`}
              onClick={() => setCurrentDayIndex(index)}
            >
              Day {index + 1}
            </button>
          ))}
          <button 
            className="px-6 py-2 rounded-lg border border-dashed border-[#CED4DA] text-[#495057] font-medium flex items-center"
            onClick={addDay}
          >
            <i className="ri-add-line mr-1"></i>
            Add Day
          </button>
        </div>
      </div>

      {/* Meal Types */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Breakfast Column */}
        <div>
          <div className="bg-white rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.05)] p-5 mb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium flex items-center">
                <i className="ri-sun-line text-[#E9C46A] mr-2"></i>
                Breakfast
              </h3>
              <span className="text-sm text-[#495057] bg-[#F8FAF9] px-2 py-1 rounded-full">
                {calculateMealCalories('breakfast')} kcal
              </span>
            </div>
            
            {getSelectedRecipe('breakfast') && (
              <div className="meal-card bg-[#F8FAF9] rounded-lg overflow-hidden mb-4 border-2 border-[#2D6A4F] transition-all">
                <div 
                  className="meal-image" 
                  style={{ backgroundImage: `url('${getSelectedRecipe('breakfast')?.imageUrl}')` }}
                ></div>
                <div className="p-4">
                  <h4 className="font-medium">{getSelectedRecipe('breakfast')?.name}</h4>
                  <div className="flex items-center mt-1 mb-2">
                    {(getSelectedRecipe('breakfast')?.dietaryTags as string[]).map(tag => (
                      <span key={tag} className="bg-[#52B788]/20 text-[#1B4332] text-xs px-2 py-0.5 rounded-full mr-2">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex justify-between text-sm text-[#495057]">
                    <span>{getSelectedRecipe('breakfast')?.calories} kcal</span>
                    <span>Prep: {getSelectedRecipe('breakfast')?.preparationTime} min</span>
                  </div>
                  <div className="mt-3 flex justify-between items-center">
                    <button 
                      className="text-[#2D6A4F] text-sm font-medium hover:text-[#1B4332] transition-all flex items-center"
                      onClick={() => getSelectedRecipe('breakfast') && onShowMealDetail(getSelectedRecipe('breakfast')!)}
                    >
                      <i className="ri-information-line mr-1"></i>
                      Details
                    </button>
                    <button className="bg-[#2D6A4F] text-white text-sm px-3 py-1.5 rounded-lg flex items-center">
                      <i className="ri-check-line mr-1"></i>
                      Selected
                    </button>
                  </div>
                </div>
              </div>
            )}
            
            {!getSelectedRecipe('breakfast') && (
              <div>
                {breakfastMeals.slice(0, 2).map(recipe => (
                  <div key={recipe.id} className="meal-card bg-[#F8FAF9] rounded-lg overflow-hidden mb-4 transition-all hover:shadow-md">
                    <div className="meal-image" style={{ backgroundImage: `url('${recipe.imageUrl}')` }}></div>
                    <div className="p-4">
                      <h4 className="font-medium">{recipe.name}</h4>
                      <div className="flex items-center mt-1 mb-2">
                        {(recipe.dietaryTags as string[]).map(tag => (
                          <span key={tag} className="bg-[#52B788]/20 text-[#1B4332] text-xs px-2 py-0.5 rounded-full mr-2">
                            {tag}
                          </span>
                        ))}
                      </div>
                      <div className="flex justify-between text-sm text-[#495057]">
                        <span>{recipe.calories} kcal</span>
                        <span>Prep: {recipe.preparationTime} min</span>
                      </div>
                      <div className="mt-3 flex justify-between items-center">
                        <button 
                          className="text-[#2D6A4F] text-sm font-medium hover:text-[#1B4332] transition-all flex items-center"
                          onClick={() => onShowMealDetail(recipe)}
                        >
                          <i className="ri-information-line mr-1"></i>
                          Details
                        </button>
                        <button 
                          className="border border-[#2D6A4F] text-[#2D6A4F] text-sm px-3 py-1.5 rounded-lg hover:bg-[#2D6A4F] hover:text-white transition-all flex items-center"
                          onClick={() => selectRecipe(recipe)}
                        >
                          <i className="ri-add-line mr-1"></i>
                          Select
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            <button 
              className="w-full py-2.5 border border-[#CED4DA] border-dashed rounded-lg text-[#495057] hover:text-[#2D6A4F] hover:border-[#2D6A4F] font-medium transition-all flex items-center justify-center"
              onClick={() => onShowMealDetail(breakfastMeals[0])}
            >
              <i className="ri-add-line mr-1"></i>
              Browse Breakfast
            </button>
          </div>
        </div>
        
        {/* Lunch Column */}
        <div>
          <div className="bg-white rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.05)] p-5 mb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium flex items-center">
                <i className="ri-sun-foggy-line text-[#9C6644] mr-2"></i>
                Lunch
              </h3>
              <span className="text-sm text-[#495057] bg-[#F8FAF9] px-2 py-1 rounded-full">
                {calculateMealCalories('lunch')} kcal
              </span>
            </div>
            
            {getSelectedRecipe('lunch') && (
              <div className="meal-card bg-[#F8FAF9] rounded-lg overflow-hidden mb-4 border-2 border-[#2D6A4F] transition-all">
                <div 
                  className="meal-image" 
                  style={{ backgroundImage: `url('${getSelectedRecipe('lunch')?.imageUrl}')` }}
                ></div>
                <div className="p-4">
                  <h4 className="font-medium">{getSelectedRecipe('lunch')?.name}</h4>
                  <div className="flex items-center mt-1 mb-2">
                    {(getSelectedRecipe('lunch')?.dietaryTags as string[]).map(tag => (
                      <span key={tag} className="bg-[#52B788]/20 text-[#1B4332] text-xs px-2 py-0.5 rounded-full mr-2">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex justify-between text-sm text-[#495057]">
                    <span>{getSelectedRecipe('lunch')?.calories} kcal</span>
                    <span>Prep: {getSelectedRecipe('lunch')?.preparationTime} min</span>
                  </div>
                  <div className="mt-3 flex justify-between items-center">
                    <button 
                      className="text-[#2D6A4F] text-sm font-medium hover:text-[#1B4332] transition-all flex items-center"
                      onClick={() => getSelectedRecipe('lunch') && onShowMealDetail(getSelectedRecipe('lunch')!)}
                    >
                      <i className="ri-information-line mr-1"></i>
                      Details
                    </button>
                    <button className="bg-[#2D6A4F] text-white text-sm px-3 py-1.5 rounded-lg flex items-center">
                      <i className="ri-check-line mr-1"></i>
                      Selected
                    </button>
                  </div>
                </div>
              </div>
            )}
            
            {!getSelectedRecipe('lunch') && lunchMeals.slice(0, 2).map(recipe => (
              <div key={recipe.id} className="meal-card bg-[#F8FAF9] rounded-lg overflow-hidden mb-4 transition-all hover:shadow-md">
                <div className="meal-image" style={{ backgroundImage: `url('${recipe.imageUrl}')` }}></div>
                <div className="p-4">
                  <h4 className="font-medium">{recipe.name}</h4>
                  <div className="flex items-center mt-1 mb-2">
                    {(recipe.dietaryTags as string[]).map(tag => (
                      <span key={tag} className="bg-[#52B788]/20 text-[#1B4332] text-xs px-2 py-0.5 rounded-full mr-2">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex justify-between text-sm text-[#495057]">
                    <span>{recipe.calories} kcal</span>
                    <span>Prep: {recipe.preparationTime} min</span>
                  </div>
                  <div className="mt-3 flex justify-between items-center">
                    <button 
                      className="text-[#2D6A4F] text-sm font-medium hover:text-[#1B4332] transition-all flex items-center"
                      onClick={() => onShowMealDetail(recipe)}
                    >
                      <i className="ri-information-line mr-1"></i>
                      Details
                    </button>
                    <button 
                      className="border border-[#2D6A4F] text-[#2D6A4F] text-sm px-3 py-1.5 rounded-lg hover:bg-[#2D6A4F] hover:text-white transition-all flex items-center"
                      onClick={() => selectRecipe(recipe)}
                    >
                      <i className="ri-add-line mr-1"></i>
                      Select
                    </button>
                  </div>
                </div>
              </div>
            ))}
            
            <button 
              className="w-full py-2.5 border border-[#CED4DA] border-dashed rounded-lg text-[#495057] hover:text-[#2D6A4F] hover:border-[#2D6A4F] font-medium transition-all flex items-center justify-center"
              onClick={() => onShowMealDetail(lunchMeals[0])}
            >
              <i className="ri-add-line mr-1"></i>
              Browse Lunch
            </button>
          </div>
        </div>
        
        {/* Dinner Column */}
        <div>
          <div className="bg-white rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.05)] p-5 mb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium flex items-center">
                <i className="ri-moon-line text-[#495057] mr-2"></i>
                Dinner
              </h3>
              <span className="text-sm text-[#495057] bg-[#F8FAF9] px-2 py-1 rounded-full">
                {calculateMealCalories('dinner')} kcal
              </span>
            </div>
            
            {getSelectedRecipe('dinner') && (
              <div className="meal-card bg-[#F8FAF9] rounded-lg overflow-hidden mb-4 border-2 border-[#2D6A4F] transition-all">
                <div 
                  className="meal-image" 
                  style={{ backgroundImage: `url('${getSelectedRecipe('dinner')?.imageUrl}')` }}
                ></div>
                <div className="p-4">
                  <h4 className="font-medium">{getSelectedRecipe('dinner')?.name}</h4>
                  <div className="flex items-center mt-1 mb-2">
                    {(getSelectedRecipe('dinner')?.dietaryTags as string[]).map(tag => (
                      <span key={tag} className="bg-[#52B788]/20 text-[#1B4332] text-xs px-2 py-0.5 rounded-full mr-2">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex justify-between text-sm text-[#495057]">
                    <span>{getSelectedRecipe('dinner')?.calories} kcal</span>
                    <span>Prep: {getSelectedRecipe('dinner')?.preparationTime} min</span>
                  </div>
                  <div className="mt-3 flex justify-between items-center">
                    <button 
                      className="text-[#2D6A4F] text-sm font-medium hover:text-[#1B4332] transition-all flex items-center"
                      onClick={() => getSelectedRecipe('dinner') && onShowMealDetail(getSelectedRecipe('dinner')!)}
                    >
                      <i className="ri-information-line mr-1"></i>
                      Details
                    </button>
                    <button className="bg-[#2D6A4F] text-white text-sm px-3 py-1.5 rounded-lg flex items-center">
                      <i className="ri-check-line mr-1"></i>
                      Selected
                    </button>
                  </div>
                </div>
              </div>
            )}
            
            {!getSelectedRecipe('dinner') && dinnerMeals.slice(0, 2).map(recipe => (
              <div key={recipe.id} className="meal-card bg-[#F8FAF9] rounded-lg overflow-hidden mb-4 transition-all hover:shadow-md">
                <div className="meal-image" style={{ backgroundImage: `url('${recipe.imageUrl}')` }}></div>
                <div className="p-4">
                  <h4 className="font-medium">{recipe.name}</h4>
                  <div className="flex items-center mt-1 mb-2">
                    {(recipe.dietaryTags as string[]).map(tag => (
                      <span key={tag} className="bg-[#52B788]/20 text-[#1B4332] text-xs px-2 py-0.5 rounded-full mr-2">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex justify-between text-sm text-[#495057]">
                    <span>{recipe.calories} kcal</span>
                    <span>Prep: {recipe.preparationTime} min</span>
                  </div>
                  <div className="mt-3 flex justify-between items-center">
                    <button 
                      className="text-[#2D6A4F] text-sm font-medium hover:text-[#1B4332] transition-all flex items-center"
                      onClick={() => onShowMealDetail(recipe)}
                    >
                      <i className="ri-information-line mr-1"></i>
                      Details
                    </button>
                    <button 
                      className="border border-[#2D6A4F] text-[#2D6A4F] text-sm px-3 py-1.5 rounded-lg hover:bg-[#2D6A4F] hover:text-white transition-all flex items-center"
                      onClick={() => selectRecipe(recipe)}
                    >
                      <i className="ri-add-line mr-1"></i>
                      Select
                    </button>
                  </div>
                </div>
              </div>
            ))}
            
            <button 
              className="w-full py-2.5 border border-[#CED4DA] border-dashed rounded-lg text-[#495057] hover:text-[#2D6A4F] hover:border-[#2D6A4F] font-medium transition-all flex items-center justify-center"
              onClick={() => onShowMealDetail(dinnerMeals[0])}
            >
              <i className="ri-add-line mr-1"></i>
              Browse Dinner
            </button>
          </div>
        </div>
      </div>
      
      {/* Snacks Section */}
      <div className="bg-white rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.05)] p-5 mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium flex items-center">
            <i className="ri-apple-line text-[#40916C] mr-2"></i>
            Snacks
          </h3>
          <span className="text-sm text-[#495057] bg-[#F8FAF9] px-2 py-1 rounded-full">
            {calculateMealCalories('snack')} kcal
          </span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {snackMeals.map(recipe => (
            <div 
              key={recipe.id}
              className={`rounded-lg overflow-hidden bg-[#F8FAF9] p-3 ${
                isRecipeSelected(recipe.id, 'snack') 
                  ? 'border-2 border-[#2D6A4F]' 
                  : 'border border-[#CED4DA] hover:border-[#2D6A4F]'
              } transition-all cursor-pointer`}
              onClick={() => selectRecipe(recipe)}
            >
              <div className="flex items-center">
                <div className="w-12 h-12 mr-3 rounded-lg overflow-hidden">
                  <img src={recipe.imageUrl} alt={recipe.name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <h4 className="font-medium text-sm">{recipe.name}</h4>
                  <div className="text-xs text-[#495057]">{recipe.calories} kcal</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="flex justify-end mt-6">
        <button 
          onClick={handleNext}
          className="bg-[#2D6A4F] hover:bg-[#1B4332] text-white font-medium px-5 py-2.5 rounded-lg transition-all flex items-center"
        >
          Continue to Nutrition Summary
          <i className="ri-arrow-right-line ml-2"></i>
        </button>
      </div>
    </section>
  );
};

export default MealSelection;
